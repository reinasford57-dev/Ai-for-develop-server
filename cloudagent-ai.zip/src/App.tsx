import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation.js';
import { AgentChat } from './components/AgentChat.js';
import { VpsDashboard } from './components/VpsDashboard.js';
import { LiveTerminal } from './components/LiveTerminal.js';
import { FileManager } from './components/FileManager.js';
import { TaskManager } from './components/TaskManager.js';
import { AuditView } from './components/AuditView.js';
import { SettingsModal } from './components/SettingsModal.js';
import { VPS } from './types.js';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('agent');
  const [servers, setServers] = useState<VPS[]>([]);
  const [selectedVpsId, setSelectedVpsId] = useState<string | undefined>(undefined);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [settingsOpen, setSettingsOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchServers();
  }, []);

  const fetchServers = async () => {
    try {
      const res = await fetch('/api/servers');
      const data = await res.json();
      if (data.servers) {
        setServers(data.servers);
        if (!selectedVpsId && data.servers.length > 0) {
          setSelectedVpsId(data.servers[0].id);
        }
      }
    } catch (err) {
      console.error('Failed to fetch servers:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top and Sidebar Navigation */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        servers={servers}
        selectedVpsId={selectedVpsId}
        setSelectedVpsId={setSelectedVpsId}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
        onOpenSettings={() => setSettingsOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 lg:pl-64 flex flex-col">
        {activeTab === 'agent' && (
          <AgentChat
            servers={servers}
            selectedVpsId={selectedVpsId}
            setSelectedVpsId={setSelectedVpsId}
            onRefreshServers={fetchServers}
          />
        )}

        {activeTab === 'dashboard' && (
          <VpsDashboard
            servers={servers}
            selectedVpsId={selectedVpsId}
            setSelectedVpsId={setSelectedVpsId}
            onRefreshServers={fetchServers}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'terminal' && (
          <LiveTerminal
            servers={servers}
            selectedVpsId={selectedVpsId}
            setSelectedVpsId={setSelectedVpsId}
          />
        )}

        {activeTab === 'files' && (
          <FileManager
            servers={servers}
            selectedVpsId={selectedVpsId}
            setSelectedVpsId={setSelectedVpsId}
          />
        )}

        {activeTab === 'tasks' && (
          <TaskManager
            servers={servers}
            selectedVpsId={selectedVpsId}
          />
        )}

        {activeTab === 'audit' && (
          <AuditView />
        )}
      </main>

      {/* Global Settings Modal */}
      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
      />
    </div>
  );
}
