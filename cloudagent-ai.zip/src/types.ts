export interface VPS {
  id: string;
  name: string;
  host: string;
  port: number;
  username: string;
  authType: 'key' | 'password';
  encryptedSecret?: string;
  encryptedPassphrase?: string;
  fingerprint?: string;
  tags: string[];
  status: 'online' | 'offline' | 'untested' | 'error';
  lastChecked?: string;
  osInfo?: {
    distro: string;
    release: string;
    kernel: string;
    arch: string;
  };
  metrics?: {
    cpuUsage: number;
    ramUsage: number;
    ramUsedMB: number;
    ramTotalMB: number;
    diskUsage: number;
    diskUsedGB: number;
    diskTotalGB: number;
    uptime: string;
    loadAvg: [number, number, number];
    processCount: number;
    dockerRunning?: number;
  };
  isDemo?: boolean;
}

export interface PlanStep {
  id: number;
  title: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'skipped';
  details?: string;
}

export interface ToolInvocation {
  id: string;
  tool: string;
  args: Record<string, any>;
  vpsId: string;
  vpsName: string;
  status: 'pending' | 'requires_approval' | 'approved' | 'rejected' | 'running' | 'success' | 'failed';
  output?: string;
  exitCode?: number;
  error?: string;
  timestamp: string;
  diff?: {
    filePath: string;
    before: string;
    after: string;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  targetVpsId?: string;
  plan?: {
    summary: string;
    steps: PlanStep[];
  };
  toolInvocations?: ToolInvocation[];
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  targetVpsId?: string;
  messages: ChatMessage[];
}

export interface FileEntry {
  name: string;
  path: string;
  size: number;
  isDirectory: boolean;
  permissions: string;
  modifiedTime: string;
}

export interface BackupSnapshot {
  id: string;
  vpsId: string;
  filePath: string;
  content: string;
  createdAt: string;
  description: string;
  sizeBytes: number;
}

export interface TaskJob {
  id: string;
  title: string;
  vpsId: string;
  vpsName: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  logs: string[];
  createdAt: string;
  completedAt?: string;
  error?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  vpsId?: string;
  vpsName?: string;
  action: string;
  actor: 'user' | 'agent';
  details: string;
  status: 'success' | 'failed' | 'warning';
  exitCode?: number;
}

export interface AppSettings {
  geminiModel: string;
  maxAgentSteps: number;
  commandTimeoutSeconds: number;
  requireApprovalForRisky: boolean;
  systemPromptCustom: string;
}
