import React, { useState, useEffect } from 'react';
import { ShieldAlert, RefreshCw, User, Bot, CheckCircle2, AlertTriangle, Terminal } from 'lucide-react';
import { AuditLog } from '../types.js';

export const AuditView: React.FC = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadAuditLogs();
  }, []);

  const loadAuditLogs = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/audit');
      const data = await res.json();
      if (data.logs) {
        setLogs(data.logs);
      }
    } catch (err) {
      console.error('Failed to load audit logs:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <ShieldAlert className="h-6 w-6 text-cyan-400" />
            Security & Compliance Audit Trail
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Immutable log of all user commands, autonomous AI tool calls, approvals, and credential operations.
          </p>
        </div>

        <button
          onClick={loadAuditLogs}
          className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-300 hover:text-white"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh Audit
        </button>
      </div>

      {/* Audit Log Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="border-b border-slate-800 bg-slate-900/80 text-[11px] text-slate-400 font-sans">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Actor</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Server Target</th>
                <th className="py-3 px-4">Details</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-900/50">
                  <td className="py-3 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleString()}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-sans font-semibold ${
                        log.actor === 'agent'
                          ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                          : 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                      }`}
                    >
                      {log.actor === 'agent' ? <Bot className="h-3 w-3" /> : <User className="h-3 w-3" />}
                      {log.actor.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-white font-semibold whitespace-nowrap">
                    {log.action}
                  </td>
                  <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                    {log.vpsName || 'All / Fleet'}
                  </td>
                  <td className="py-3 px-4 max-w-md truncate text-slate-300">
                    {log.details}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span
                      className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${
                        log.status === 'success'
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : 'bg-rose-500/10 text-rose-400'
                      }`}
                    >
                      {log.status.toUpperCase()}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
