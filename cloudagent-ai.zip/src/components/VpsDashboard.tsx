import React, { useState } from 'react';
import { 
  Server, 
  Plus, 
  RefreshCw, 
  Cpu, 
  HardDrive, 
  Activity, 
  Terminal, 
  FolderTree, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  AlertCircle, 
  ExternalLink,
  Search,
  Tag,
  Key,
  Lock,
  Layers
} from 'lucide-react';
import { VPS } from '../types.js';

interface VpsDashboardProps {
  servers: VPS[];
  selectedVpsId?: string;
  setSelectedVpsId: (id: string) => void;
  onRefreshServers: () => void;
  onNavigateTab: (tab: string) => void;
}

export const VpsDashboard: React.FC<VpsDashboardProps> = ({
  servers,
  selectedVpsId,
  setSelectedVpsId,
  onRefreshServers,
  onNavigateTab,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDetailDrawerOpen, setIsDetailDrawerOpen] = useState(false);
  const [inspectedVps, setInspectedVps] = useState<VPS | null>(null);
  const [testingId, setTestingId] = useState<string | null>(null);

  // Add Server Form State
  const [formName, setFormName] = useState('');
  const [formHost, setFormHost] = useState('');
  const [formPort, setFormPort] = useState('22');
  const [formUser, setFormUser] = useState('root');
  const [formAuthType, setFormAuthType] = useState<'key' | 'password'>('key');
  const [formSecret, setFormSecret] = useState('');
  const [formPassphrase, setFormPassphrase] = useState('');
  const [formTags, setFormTags] = useState('production, web');
  const [addLoading, setAddLoading] = useState(false);
  const [addTestResult, setAddTestResult] = useState<any>(null);

  // All distinct tags
  const allTags = Array.from(new Set(servers.flatMap((s) => s.tags || [])));

  const filteredServers = servers.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.host.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.username.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTag = selectedTag === 'all' || s.tags?.includes(selectedTag);
    return matchesSearch && matchesTag;
  });

  const handleTestConnection = async (vpsId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setTestingId(vpsId);
    try {
      const res = await fetch(`/api/servers/${vpsId}/test`, { method: 'POST' });
      await res.json();
      onRefreshServers();
    } catch (err) {
      console.error('Failed to test connection:', err);
    } finally {
      setTestingId(null);
    }
  };

  const handleDeleteServer = async (vpsId: string, name: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm(`Are you sure you want to remove server "${name}"?`)) return;
    try {
      await fetch(`/api/servers/${vpsId}`, { method: 'DELETE' });
      onRefreshServers();
    } catch (err) {
      console.error('Failed to delete server:', err);
    }
  };

  const handleSaveNewServer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formHost || !formUser || !formSecret) {
      alert('Please fill out all required fields.');
      return;
    }

    setAddLoading(true);
    setAddTestResult(null);

    try {
      const tagsArray = formTags.split(',').map((t) => t.trim()).filter(Boolean);
      const res = await fetch('/api/servers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName,
          host: formHost,
          port: parseInt(formPort, 10) || 22,
          username: formUser,
          authType: formAuthType,
          secret: formSecret,
          passphrase: formPassphrase,
          tags: tagsArray,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setIsAddModalOpen(false);
        resetForm();
        onRefreshServers();
      } else {
        setAddTestResult({ success: false, error: data.error || 'Failed to save server.' });
      }
    } catch (err: any) {
      setAddTestResult({ success: false, error: err.message });
    } finally {
      setAddLoading(false);
    }
  };

  const resetForm = () => {
    setFormName('');
    setFormHost('');
    setFormPort('22');
    setFormUser('root');
    setFormAuthType('key');
    setFormSecret('');
    setFormPassphrase('');
    setFormTags('production, web');
    setAddTestResult(null);
  };

  const openServerInspector = (server: VPS) => {
    setInspectedVps(server);
    setIsDetailDrawerOpen(true);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Server className="h-6 w-6 text-cyan-400" />
            Multi-VPS Fleet Inventory
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time monitoring, SSH health, resource utilization, and autonomous agent targeting.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onRefreshServers}
            className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-300 hover:border-slate-700 hover:text-white transition-colors"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh Fleet
          </button>
          <button
            onClick={() => {
              resetForm();
              setIsAddModalOpen(true);
            }}
            className="flex items-center gap-1.5 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md shadow-cyan-950/40 hover:opacity-90 transition-opacity"
          >
            <Plus className="h-4 w-4" />
            Add Server
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between border-y border-slate-800/80 py-3">
        <div className="relative flex-1 max-w-md">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, hostname, IP, or user..."
            className="w-full rounded-xl border border-slate-800 bg-slate-900/80 py-2 pl-9 pr-3 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          />
        </div>

        {/* Tag Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setSelectedTag('all')}
            className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors ${
              selectedTag === 'all'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:bg-slate-900'
            }`}
          >
            All Nodes ({servers.length})
          </button>
          {allTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors ${
                selectedTag === tag
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:bg-slate-900'
              }`}
            >
              #{tag}
            </button>
          ))}
        </div>
      </div>

      {/* Servers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredServers.map((server) => {
          const isSelected = server.id === selectedVpsId;
          const isTesting = testingId === server.id;
          const cpu = server.metrics?.cpuUsage ?? 0;
          const ram = server.metrics?.ramUsage ?? 0;
          const disk = server.metrics?.diskUsage ?? 0;

          return (
            <div
              key={server.id}
              onClick={() => {
                setSelectedVpsId(server.id);
                openServerInspector(server);
              }}
              className={`group relative flex flex-col justify-between rounded-2xl border p-5 transition-all cursor-pointer ${
                isSelected
                  ? 'border-cyan-500/60 bg-slate-900/90 shadow-lg shadow-cyan-950/20 ring-1 ring-cyan-500/40'
                  : 'border-slate-800/90 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/70'
              }`}
            >
              {/* Card Header */}
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`flex h-9 w-9 items-center justify-center rounded-xl font-mono text-sm font-bold ${
                        server.status === 'online'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : server.status === 'error'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                      }`}
                    >
                      <Server className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-white text-sm">{server.name}</h3>
                        {server.isDemo && (
                          <span className="rounded bg-amber-500/10 px-1 py-0.2 text-[9px] font-mono text-amber-300 border border-amber-500/20">
                            Sandbox
                          </span>
                        )}
                      </div>
                      <p className="font-mono text-xs text-slate-400">
                        {server.username}@{server.host}:{server.port}
                      </p>
                    </div>
                  </div>

                  {/* Status Indicator */}
                  <span
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-mono font-medium ${
                      server.status === 'online'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}
                  >
                    <span
                      className={`h-1.5 w-1.5 rounded-full ${
                        server.status === 'online' ? 'bg-emerald-400' : 'bg-rose-400'
                      }`}
                    />
                    {server.status.toUpperCase()}
                  </span>
                </div>

                {/* OS & Host info */}
                <div className="mt-3 text-[11px] text-slate-400 flex items-center justify-between border-y border-slate-800/80 py-1.5">
                  <span>{server.osInfo?.distro || 'Linux'} {server.osInfo?.release || ''}</span>
                  <span className="font-mono text-[10px] text-slate-500">{server.osInfo?.arch || 'x86_64'}</span>
                </div>

                {/* Live Metrics Bars */}
                <div className="mt-4 space-y-2.5">
                  {/* CPU */}
                  <div>
                    <div className="flex justify-between text-[11px] font-mono mb-1">
                      <span className="text-slate-400 flex items-center gap-1">
                        <Cpu className="h-3 w-3 text-cyan-400" /> CPU
                      </span>
                      <span className="text-slate-200 font-semibold">{cpu}%</span>
                    </div>
                    <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          cpu > 80 ? 'bg-rose-500' : cpu > 50 ? 'bg-amber-400' : 'bg-cyan-500'
                        }`}
                        style={{ width: `${Math.min(100, Math.max(2, cpu))}%` }}
                      />
                    </div>
                  </div>

                  {/* RAM */}
                  <div>
                    <div className="flex justify-between text-[11px] font-mono mb-1">
                      <span className="text-slate-400 flex items-center gap-1">
                        <Activity className="h-3 w-3 text-indigo-400" /> RAM
                      </span>
                      <span className="text-slate-200 font-semibold">
                        {ram}% ({server.metrics?.ramUsedMB || 0}MB)
                      </span>
                    </div>
                    <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          ram > 85 ? 'bg-rose-500' : ram > 65 ? 'bg-amber-400' : 'bg-indigo-500'
                        }`}
                        style={{ width: `${Math.min(100, Math.max(2, ram))}%` }}
                      />
                    </div>
                  </div>

                  {/* Disk */}
                  <div>
                    <div className="flex justify-between text-[11px] font-mono mb-1">
                      <span className="text-slate-400 flex items-center gap-1">
                        <HardDrive className="h-3 w-3 text-emerald-400" /> Disk
                      </span>
                      <span className="text-slate-200 font-semibold">{disk}%</span>
                    </div>
                    <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-emerald-500 transition-all duration-500"
                        style={{ width: `${Math.min(100, Math.max(2, disk))}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Tags */}
                <div className="mt-3 flex flex-wrap gap-1">
                  {server.tags?.map((t) => (
                    <span
                      key={t}
                      className="rounded bg-slate-800/80 px-1.5 py-0.5 text-[10px] font-mono text-slate-400"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="mt-5 flex items-center justify-between border-t border-slate-800/80 pt-3">
                <button
                  onClick={(e) => handleTestConnection(server.id, e)}
                  disabled={isTesting}
                  className="flex items-center gap-1 text-[11px] font-medium text-slate-400 hover:text-cyan-400 disabled:opacity-50"
                >
                  <RefreshCw className={`h-3 w-3 ${isTesting ? 'animate-spin' : ''}`} />
                  {isTesting ? 'Testing...' : 'Test SSH'}
                </button>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedVpsId(server.id);
                      onNavigateTab('terminal');
                    }}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
                    title="Open Live Terminal"
                  >
                    <Terminal className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedVpsId(server.id);
                      onNavigateTab('files');
                    }}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
                    title="Open File Manager"
                  >
                    <FolderTree className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={(e) => handleDeleteServer(server.id, server.name, e)}
                    className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800"
                    title="Delete Server"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Server Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
          <div className="flex max-h-[90vh] w-full max-w-lg flex-col rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-2xl overflow-y-auto">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Plus className="h-5 w-5 text-cyan-400" />
              Register New Linux VPS
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              Credentials are encrypted using AES-256-GCM and stored securely in the system vault.
            </p>

            <form onSubmit={handleSaveNewServer} className="mt-5 space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-300">Server Display Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Frankfurt Web Cluster Node 01"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="font-semibold text-slate-300">Host IP / Domain *</label>
                  <input
                    type="text"
                    required
                    placeholder="198.51.100.24 or vps.domain.com"
                    value={formHost}
                    onChange={(e) => setFormHost(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-300">SSH Port</label>
                  <input
                    type="number"
                    value={formPort}
                    onChange={(e) => setFormPort(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-300">SSH Username *</label>
                  <input
                    type="text"
                    required
                    value={formUser}
                    onChange={(e) => setFormUser(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-300">Auth Method</label>
                  <select
                    value={formAuthType}
                    onChange={(e) => setFormAuthType(e.target.value as any)}
                    className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="key">SSH Private Key (Recommended)</option>
                    <option value="password">SSH Password</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-300">
                  {formAuthType === 'key' ? 'OpenSSH / ED25519 Private Key *' : 'Password *'}
                </label>
                {formAuthType === 'key' ? (
                  <textarea
                    rows={4}
                    required
                    placeholder="-----BEGIN OPENSSH PRIVATE KEY-----&#10;...&#10;-----END OPENSSH PRIVATE KEY-----"
                    value={formSecret}
                    onChange={(e) => setFormSecret(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 p-2.5 font-mono text-[11px] text-cyan-300 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
                  />
                ) : (
                  <input
                    type="password"
                    required
                    placeholder="Enter root or sudo user password"
                    value={formSecret}
                    onChange={(e) => setFormSecret(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                )}
              </div>

              {formAuthType === 'key' && (
                <div>
                  <label className="font-semibold text-slate-300">Key Passphrase (Optional)</label>
                  <input
                    type="password"
                    placeholder="Leave empty if private key has no passphrase"
                    value={formPassphrase}
                    onChange={(e) => setFormPassphrase(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              )}

              <div>
                <label className="font-semibold text-slate-300">Tags (comma-separated)</label>
                <input
                  type="text"
                  placeholder="production, web, docker, redis"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              {addTestResult && (
                <div
                  className={`rounded-xl p-3 font-mono text-[11px] ${
                    addTestResult.success
                      ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800'
                      : 'bg-rose-950/40 text-rose-300 border border-rose-800'
                  }`}
                >
                  {addTestResult.error || 'Connection verification successful!'}
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={addLoading}
                  className="rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 px-5 py-2 text-xs font-bold text-white hover:opacity-90 disabled:opacity-50"
                >
                  {addLoading ? 'Testing & Saving...' : 'Register Server'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Server Inspector Drawer */}
      {isDetailDrawerOpen && inspectedVps && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs" onClick={() => setIsDetailDrawerOpen(false)}>
          <div
            className="h-full w-full max-w-md border-l border-slate-800 bg-slate-950 p-6 shadow-2xl overflow-y-auto space-y-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-white">{inspectedVps.name}</h3>
                <p className="font-mono text-xs text-slate-400">
                  {inspectedVps.username}@{inspectedVps.host}:{inspectedVps.port}
                </p>
              </div>
              <button
                onClick={() => setIsDetailDrawerOpen(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => {
                  setSelectedVpsId(inspectedVps.id);
                  onNavigateTab('terminal');
                }}
                className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 py-2.5 font-semibold text-slate-200 hover:border-cyan-500 hover:text-cyan-400"
              >
                <Terminal className="h-3.5 w-3.5" /> Terminal
              </button>
              <button
                onClick={() => {
                  setSelectedVpsId(inspectedVps.id);
                  onNavigateTab('files');
                }}
                className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 py-2.5 font-semibold text-slate-200 hover:border-cyan-500 hover:text-cyan-400"
              >
                <FolderTree className="h-3.5 w-3.5" /> File Manager
              </button>
            </div>

            {/* Hardware & OS Specs */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 space-y-2 text-xs">
              <span className="font-semibold text-white">System Information</span>
              <div className="space-y-1 font-mono text-[11px] text-slate-300">
                <div>Distro: {inspectedVps.osInfo?.distro} {inspectedVps.osInfo?.release}</div>
                <div>Kernel: {inspectedVps.osInfo?.kernel || '6.8.0-generic'}</div>
                <div>Uptime: {inspectedVps.metrics?.uptime || '28 days'}</div>
                <div>Load Avg: {inspectedVps.metrics?.loadAvg?.join(', ') || '0.34, 0.42, 0.39'}</div>
                <div>Processes: {inspectedVps.metrics?.processCount || 142} running</div>
                <div>Docker Containers: {inspectedVps.metrics?.dockerRunning || 0} active</div>
              </div>
            </div>

            {/* Host Fingerprint */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-xs space-y-1">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <Lock className="h-3.5 w-3.5 text-cyan-400" /> Host Key Fingerprint
              </span>
              <p className="font-mono text-[10px] text-cyan-300 break-all bg-slate-950 p-2 rounded">
                {inspectedVps.fingerprint || 'SHA256:7mP4eGj89KlMnOpQrStUvWxYz0123456789abcdefgh'}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
