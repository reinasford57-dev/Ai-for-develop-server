import React, { useState, useEffect } from 'react';
import { Settings, Shield, Sliders, X, Check, Lock, Cpu } from 'lucide-react';
import { AppSettings } from '../types.js';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const [settings, setSettings] = useState<AppSettings>({
    geminiModel: 'gemini-3.8-flash',
    maxAgentSteps: 10,
    commandTimeoutSeconds: 30,
    requireApprovalForRisky: true,
    systemPromptCustom: '',
  });
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadSettings();
    }
  }, [isOpen]);

  const loadSettings = async () => {
    try {
      const res = await fetch('/api/settings');
      const data = await res.json();
      if (data.settings) {
        setSettings(data.settings);
      }
    } catch (err) {
      console.error('Failed to load settings:', err);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      if (data.settings) {
        setSettings(data.settings);
        setSavedSuccess(true);
        setTimeout(() => setSavedSuccess(false), 2000);
      }
    } catch (err) {
      console.error('Failed to update settings:', err);
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
      <div className="flex max-h-[90vh] w-full max-w-lg flex-col rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-2xl overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <Sliders className="h-5 w-5 text-cyan-400" />
            <h2 className="text-base font-bold text-white">CloudOps Platform Settings</h2>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="mt-5 space-y-5 text-xs">
          {/* Security Vault Banner */}
          <div className="rounded-xl border border-emerald-900/50 bg-emerald-950/20 p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Lock className="h-4 w-4 text-emerald-400" />
              <div>
                <span className="font-semibold text-emerald-300">AES-256-GCM Vault Active</span>
                <p className="text-[10px] text-emerald-200/70">
                  SSH credentials, private keys, and passwords are encrypted at rest with authenticated ciphers.
                </p>
              </div>
            </div>
            <span className="rounded bg-emerald-500/20 px-2 py-0.5 text-[9px] font-mono font-bold text-emerald-300">
              ENCRYPTED
            </span>
          </div>

          {/* Model Configuration */}
          <div>
            <label className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Cpu className="h-3.5 w-3.5 text-cyan-400" />
              AI Agent Model
            </label>
            <p className="text-[11px] text-slate-500 mb-1.5">
              Select the Gemini model utilized for planning, tool call analysis, and reasoning.
            </p>
            <select
              value={settings.geminiModel}
              onChange={(e) => setSettings({ ...settings, geminiModel: e.target.value })}
              className="w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono focus:border-cyan-500 focus:outline-none"
            >
              <option value="gemini-3.8-flash">gemini-3.8-flash (Recommended — Low Latency & High Tool Accuracy)</option>
              <option value="gemini-flash-latest">gemini-flash-latest</option>
            </select>
          </div>

          {/* Max Agent Steps */}
          <div>
            <div className="flex justify-between font-semibold text-slate-300">
              <span>Maximum Agent Execution Loop Steps</span>
              <span className="font-mono text-cyan-400">{settings.maxAgentSteps} steps</span>
            </div>
            <p className="text-[11px] text-slate-500 mb-1.5">
              Limits recursive tool calling iterations per user command to prevent infinite loops.
            </p>
            <input
              type="range"
              min="3"
              max="20"
              value={settings.maxAgentSteps}
              onChange={(e) => setSettings({ ...settings, maxAgentSteps: parseInt(e.target.value, 10) })}
              className="w-full accent-cyan-500"
            />
          </div>

          {/* Command Timeout */}
          <div>
            <div className="flex justify-between font-semibold text-slate-300">
              <span>SSH Command Execution Timeout</span>
              <span className="font-mono text-cyan-400">{settings.commandTimeoutSeconds}s</span>
            </div>
            <input
              type="range"
              min="10"
              max="120"
              step="5"
              value={settings.commandTimeoutSeconds}
              onChange={(e) => setSettings({ ...settings, commandTimeoutSeconds: parseInt(e.target.value, 10) })}
              className="w-full accent-cyan-500"
            />
          </div>

          {/* High-Risk Approval Toggle */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3.5 flex items-start gap-3">
            <input
              type="checkbox"
              id="requireApproval"
              checked={settings.requireApprovalForRisky}
              onChange={(e) => setSettings({ ...settings, requireApprovalForRisky: e.target.checked })}
              className="mt-0.5 rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-cyan-500"
            />
            <label htmlFor="requireApproval" className="cursor-pointer space-y-0.5">
              <span className="font-semibold text-white block">Mandatory Approval for High-Risk Actions</span>
              <span className="text-[11px] text-slate-400 block leading-normal">
                Pause and require explicit user authorization before deleting files, modifying system firewall rules, restarting critical networking services, or uninstalling packages.
              </span>
            </label>
          </div>

          {/* Custom System Prompt Instructions */}
          <div>
            <label className="font-semibold text-slate-300">Custom Agent Directives (Optional)</label>
            <p className="text-[11px] text-slate-500 mb-1.5">
              Append global policy rules or fleet conventions to the autonomous agent's system prompt.
            </p>
            <textarea
              rows={3}
              placeholder="e.g. Always verify nginx configuration with nginx -t before restarting. Prefer systemd service units over direct binary execution."
              value={settings.systemPromptCustom}
              onChange={(e) => setSettings({ ...settings, systemPromptCustom: e.target.value })}
              className="w-full rounded-xl border border-slate-800 bg-slate-900 p-2.5 font-mono text-[11px] text-slate-200 placeholder-slate-600 focus:border-cyan-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-1.5 rounded-xl bg-cyan-600 px-5 py-2 text-xs font-bold text-white hover:bg-cyan-500 shadow-md"
            >
              {savedSuccess ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-300" /> Saved!
                </>
              ) : (
                saving ? 'Saving...' : 'Save Settings'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
