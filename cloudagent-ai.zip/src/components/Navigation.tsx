import React from 'react';
import { 
  Bot, 
  Server, 
  Terminal, 
  FolderTree, 
  ListTodo, 
  ShieldAlert, 
  Settings, 
  Menu, 
  X,
  CircleDot,
  ChevronDown
} from 'lucide-react';
import { VPS } from '../types.js';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  servers: VPS[];
  selectedVpsId?: string;
  setSelectedVpsId: (id: string) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
  onOpenSettings: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  servers,
  selectedVpsId,
  setSelectedVpsId,
  mobileMenuOpen,
  setMobileMenuOpen,
  onOpenSettings,
}) => {
  const selectedServer = servers.find((s) => s.id === selectedVpsId) || servers[0];
  const onlineCount = servers.filter((s) => s.status === 'online').length;

  const navItems = [
    { id: 'agent', label: 'AI Cloud Agent', icon: Bot, badge: 'Active' },
    { id: 'dashboard', label: 'Fleet Dashboard', icon: Server, badge: `${onlineCount}/${servers.length}` },
    { id: 'terminal', label: 'Live Terminal', icon: Terminal },
    { id: 'files', label: 'File Manager & Diff', icon: FolderTree },
    { id: 'tasks', label: 'Background Tasks', icon: ListTodo },
    { id: 'audit', label: 'Security & Audit', icon: ShieldAlert },
  ];

  return (
    <>
      {/* Top Header */}
      <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-800 bg-slate-950/80 px-4 backdrop-blur-md sm:px-6">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white lg:hidden"
            aria-label="Toggle navigation"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 shadow-md shadow-cyan-950/50">
              <Bot className="h-5 w-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold tracking-tight text-white text-base">CloudOps</span>
                <span className="rounded bg-cyan-950 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-cyan-400 border border-cyan-800/60">
                  AI AGENT
                </span>
              </div>
              <p className="hidden sm:block text-[11px] text-slate-400 font-normal">
                Multi-VPS Autonomous Cloud Control
              </p>
            </div>
          </div>
        </div>

        {/* Server Quick Selector & Actions */}
        <div className="flex items-center gap-3">
          {/* Active Target VPS Pill */}
          <div className="relative">
            <select
              value={selectedVpsId || (servers[0]?.id || '')}
              onChange={(e) => setSelectedVpsId(e.target.value)}
              className="appearance-none rounded-lg border border-slate-700 bg-slate-900/90 py-1.5 pl-8 pr-8 text-xs font-medium text-slate-200 transition-colors hover:border-slate-600 focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            >
              {servers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.host})
                </option>
              ))}
            </select>
            <CircleDot
              className={`pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 ${
                selectedServer?.status === 'online'
                  ? 'text-emerald-400'
                  : selectedServer?.status === 'error'
                  ? 'text-rose-400'
                  : 'text-amber-400'
              }`}
            />
            <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
          </div>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-400 transition-colors hover:border-slate-700 hover:text-white"
            title="System Settings"
          >
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs lg:hidden" onClick={() => setMobileMenuOpen(false)}>
          <div
            className="fixed inset-y-0 left-0 w-72 border-r border-slate-800 bg-slate-950 p-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <span className="text-sm font-semibold text-slate-200">Navigation</span>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="rounded-lg p-1 text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="mt-4 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                      isActive
                        ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                        : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-mono text-slate-400">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      )}

      {/* Desktop Sidebar Navigation */}
      <aside className="hidden lg:fixed lg:bottom-0 lg:left-0 lg:top-16 lg:z-20 lg:flex lg:w-64 lg:flex-col lg:border-r lg:border-slate-800 lg:bg-slate-950/60 lg:p-4">
        <div className="mb-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
          Control Center
        </div>
        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/25 shadow-sm'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`h-4 w-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`rounded px-1.5 py-0.5 font-mono text-[10px] ${
                      isActive
                        ? 'bg-cyan-500/20 text-cyan-300'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Selected VPS Status Card */}
        <div className="mt-auto rounded-xl border border-slate-800/80 bg-slate-900/60 p-3">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
            <span className="font-semibold text-slate-300">Target Node</span>
            <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-mono">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
              {selectedServer?.status || 'Active'}
            </span>
          </div>
          <div className="font-mono text-xs text-white font-medium truncate">
            {selectedServer?.name || 'No VPS selected'}
          </div>
          <div className="text-[11px] font-mono text-slate-400 truncate">
            {selectedServer?.host || '127.0.0.1'}:{selectedServer?.port || 22}
          </div>
          {selectedServer?.metrics && (
            <div className="mt-2.5 grid grid-cols-2 gap-2 border-t border-slate-800/80 pt-2 text-[10px] font-mono">
              <div>
                <span className="text-slate-500">CPU:</span>{' '}
                <span className="text-slate-300 font-semibold">{selectedServer.metrics.cpuUsage}%</span>
              </div>
              <div>
                <span className="text-slate-500">RAM:</span>{' '}
                <span className="text-slate-300 font-semibold">{selectedServer.metrics.ramUsage}%</span>
              </div>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
