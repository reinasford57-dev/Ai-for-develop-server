import React, { useState, useEffect } from 'react';
import { 
  FolderTree, 
  File, 
  Folder, 
  ArrowLeft, 
  Save, 
  RotateCcw, 
  FileCode, 
  RefreshCw, 
  ShieldAlert, 
  FileText,
  Clock,
  Check
} from 'lucide-react';
import { VPS, FileEntry, BackupSnapshot } from '../types.js';

interface FileManagerProps {
  servers: VPS[];
  selectedVpsId?: string;
  setSelectedVpsId: (id: string) => void;
}

export const FileManager: React.FC<FileManagerProps> = ({
  servers,
  selectedVpsId,
  setSelectedVpsId,
}) => {
  const currentVps = servers.find((s) => s.id === selectedVpsId) || servers[0];

  const [currentPath, setCurrentPath] = useState<string>('/etc/nginx');
  const [entries, setEntries] = useState<FileEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [selectedFile, setSelectedFile] = useState<string | null>('/etc/nginx/nginx.conf');
  const [fileContent, setFileContent] = useState<string>('');
  const [originalContent, setOriginalContent] = useState<string>('');
  const [saving, setSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [backups, setBackups] = useState<BackupSnapshot[]>([]);
  const [activeTab, setActiveTab] = useState<'editor' | 'backups'>('editor');
  const [rollbackSuccess, setRollbackSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (currentVps) {
      loadDirectory(currentPath);
      if (selectedFile) {
        loadFileContent(selectedFile);
        loadBackups(selectedFile);
      }
    }
  }, [currentVps?.id, currentPath]);

  const loadDirectory = async (dirPath: string) => {
    if (!currentVps) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/files/list?vpsId=${currentVps.id}&path=${encodeURIComponent(dirPath)}`);
      const data = await res.json();
      if (data.files) {
        setEntries(data.files);
      }
    } catch (err) {
      console.error('Failed to list files:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadFileContent = async (filePath: string) => {
    if (!currentVps) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/files/read?vpsId=${currentVps.id}&filePath=${encodeURIComponent(filePath)}`);
      const data = await res.json();
      if (data.content !== undefined) {
        setFileContent(data.content);
        setOriginalContent(data.content);
        setSelectedFile(filePath);
        loadBackups(filePath);
      }
    } catch (err) {
      console.error('Failed to read file:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadBackups = async (filePath: string) => {
    if (!currentVps) return;
    try {
      const res = await fetch(`/api/files/backups?vpsId=${currentVps.id}&filePath=${encodeURIComponent(filePath)}`);
      const data = await res.json();
      if (data.backups) {
        setBackups(data.backups);
      }
    } catch (err) {
      console.error('Failed to load backups:', err);
    }
  };

  const handleSaveFile = async () => {
    if (!currentVps || !selectedFile) return;
    setSaving(true);
    try {
      const res = await fetch('/api/files/write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vpsId: currentVps.id,
          filePath: selectedFile,
          content: fileContent,
          description: `Manual edit via Web File Manager at ${new Date().toLocaleTimeString()}`,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setOriginalContent(fileContent);
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 2000);
        loadBackups(selectedFile);
      }
    } catch (err) {
      console.error('Failed to save file:', err);
    } finally {
      setSaving(false);
    }
  };

  const handleRollback = async (backupId: string) => {
    if (!confirm('Are you sure you want to revert this file to the selected snapshot?')) return;
    try {
      const res = await fetch('/api/files/rollback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ backupId }),
      });
      const data = await res.json();
      if (data.success && selectedFile) {
        setRollbackSuccess(backupId);
        setTimeout(() => setRollbackSuccess(null), 2500);
        loadFileContent(selectedFile);
      }
    } catch (err) {
      console.error('Failed to rollback:', err);
    }
  };

  const navigateUp = () => {
    const parts = currentPath.split('/').filter(Boolean);
    parts.pop();
    const parentPath = parts.length === 0 ? '/' : `/${parts.join('/')}`;
    setCurrentPath(parentPath);
  };

  const quickDirs = [
    { label: '/etc/nginx', path: '/etc/nginx' },
    { label: '/var/log', path: '/var/log' },
    { label: '/var/www', path: '/var/www' },
    { label: '/etc/docker', path: '/etc/docker' },
    { label: '/etc', path: '/etc' },
  ];

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col lg:flex-row bg-slate-950">
      {/* Left: Remote Directory Tree */}
      <div className="w-full lg:w-80 flex flex-col border-r border-slate-800 bg-slate-950/60 p-4">
        {/* Server & Breadcrumb */}
        <div className="space-y-2 border-b border-slate-800 pb-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-400">Target Server</span>
            <select
              value={selectedVpsId || currentVps?.id}
              onChange={(e) => setSelectedVpsId(e.target.value)}
              className="rounded border border-slate-700 bg-slate-900 px-2 py-0.5 text-xs text-white"
            >
              {servers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 font-mono text-xs">
            <button
              onClick={navigateUp}
              disabled={currentPath === '/'}
              className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white disabled:opacity-30"
              title="Parent Directory"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
            </button>
            <span className="truncate text-cyan-400 font-semibold">{currentPath}</span>
            <button
              onClick={() => loadDirectory(currentPath)}
              className="ml-auto rounded p-1 text-slate-400 hover:text-white"
              title="Refresh"
            >
              <RefreshCw className={`h-3 w-3 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* Quick Dirs */}
          <div className="flex flex-wrap gap-1 pt-1">
            {quickDirs.map((qd) => (
              <button
                key={qd.path}
                onClick={() => setCurrentPath(qd.path)}
                className={`rounded px-1.5 py-0.5 font-mono text-[10px] ${
                  currentPath === qd.path
                    ? 'bg-cyan-500/20 text-cyan-300 font-bold'
                    : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                }`}
              >
                {qd.label}
              </button>
            ))}
          </div>
        </div>

        {/* Directory Item List */}
        <div className="flex-1 overflow-y-auto mt-3 space-y-1 font-mono text-xs pr-1">
          {entries.length === 0 && !loading && (
            <div className="py-6 text-center text-slate-500 text-xs">No files or empty directory</div>
          )}

          {entries.map((entry) => (
            <div
              key={entry.path}
              onClick={() => {
                if (entry.isDirectory) {
                  setCurrentPath(entry.path);
                } else {
                  loadFileContent(entry.path);
                }
              }}
              className={`flex items-center justify-between rounded-lg px-2.5 py-1.5 cursor-pointer transition-colors ${
                selectedFile === entry.path
                  ? 'bg-cyan-500/20 text-cyan-300 font-medium'
                  : 'text-slate-300 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-2 truncate">
                {entry.isDirectory ? (
                  <Folder className="h-4 w-4 text-amber-400 shrink-0" />
                ) : (
                  <File className="h-4 w-4 text-cyan-400 shrink-0" />
                )}
                <span className="truncate">{entry.name}</span>
              </div>
              <span className="text-[10px] text-slate-500 shrink-0">
                {entry.isDirectory ? 'DIR' : `${entry.size} B`}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Right: File Editor & Diff / Snapshots */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Editor Tab Navigation */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/60 px-4 py-2 text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 font-mono text-white">
              <FileCode className="h-4 w-4 text-cyan-400" />
              <span>{selectedFile || 'Select a file to inspect'}</span>
            </div>

            <div className="flex items-center gap-1 border-l border-slate-700 pl-3">
              <button
                onClick={() => setActiveTab('editor')}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold ${
                  activeTab === 'editor'
                    ? 'bg-slate-800 text-cyan-400'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Code Editor
              </button>
              <button
                onClick={() => setActiveTab('backups')}
                className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-semibold ${
                  activeTab === 'backups'
                    ? 'bg-slate-800 text-cyan-400'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Clock className="h-3 w-3" />
                Snapshots ({backups.length})
              </button>
            </div>
          </div>

          {activeTab === 'editor' && (
            <div className="flex items-center gap-2">
              {fileContent !== originalContent && (
                <span className="text-[11px] font-mono text-amber-400">Unsaved Changes</span>
              )}
              <button
                onClick={handleSaveFile}
                disabled={saving || !selectedFile}
                className="flex items-center gap-1.5 rounded-xl bg-cyan-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-cyan-500 disabled:opacity-50 transition-colors shadow-sm"
              >
                {saveSuccess ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-300" /> Saved!
                  </>
                ) : (
                  <>
                    <Save className="h-3.5 w-3.5" />
                    {saving ? 'Saving...' : 'Save & Snapshot'}
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Content View */}
        {activeTab === 'editor' ? (
          <div className="flex-1 p-4 bg-slate-950 overflow-hidden flex flex-col">
            <textarea
              value={fileContent}
              onChange={(e) => setFileContent(e.target.value)}
              placeholder="Select a remote configuration file from the directory tree to view and edit..."
              className="flex-1 w-full resize-none rounded-xl border border-slate-800 bg-slate-900/90 p-4 font-mono text-xs leading-relaxed text-slate-200 focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              spellCheck={false}
            />
          </div>
        ) : (
          /* Snapshots & Rollback History View */
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <RotateCcw className="h-4 w-4 text-cyan-400" />
                Automatic Pre-Edit Snapshots for {selectedFile}
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                Every time this file is edited by the agent or user, a full pristine snapshot is saved. You can restore any previous version instantly.
              </p>
            </div>

            {backups.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                No backup snapshots recorded yet for this file.
              </div>
            ) : (
              backups.map((b) => (
                <div
                  key={b.id}
                  className="rounded-xl border border-slate-800 bg-slate-900/80 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-semibold text-white">{b.id}</span>
                      <span className="text-[10px] text-slate-400">{new Date(b.createdAt).toLocaleString()}</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">{b.description}</p>
                    <span className="text-[10px] font-mono text-slate-500">Size: {b.sizeBytes} bytes</span>
                  </div>

                  <button
                    onClick={() => handleRollback(b.id)}
                    className="flex items-center justify-center gap-1.5 rounded-xl border border-cyan-500/30 bg-cyan-500/10 px-4 py-2 text-xs font-semibold text-cyan-300 hover:bg-cyan-500/20 transition-colors"
                  >
                    {rollbackSuccess === b.id ? (
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                    ) : (
                      <RotateCcw className="h-3.5 w-3.5" />
                    )}
                    Restore This Snapshot
                  </button>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
