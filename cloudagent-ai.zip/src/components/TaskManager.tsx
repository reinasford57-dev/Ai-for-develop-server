import React, { useState, useEffect } from 'react';
import { ListTodo, Play, CheckCircle2, XCircle, Clock, Terminal, Plus, RefreshCw } from 'lucide-react';
import { TaskJob, VPS } from '../types.js';

interface TaskManagerProps {
  servers: VPS[];
  selectedVpsId?: string;
}

export const TaskManager: React.FC<TaskManagerProps> = ({ servers, selectedVpsId }) => {
  const [tasks, setTasks] = useState<TaskJob[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [taskTitle, setTaskTitle] = useState('System Security Audit & Upgrade');
  const [taskScript, setTaskScript] = useState('apt-get update && apt-get -s upgrade && df -h');
  const [targetVps, setTargetVps] = useState(selectedVpsId || (servers[0]?.id || ''));
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadTasks();
    const interval = setInterval(loadTasks, 4000);
    return () => clearInterval(interval);
  }, []);

  const loadTasks = async () => {
    try {
      const res = await fetch('/api/tasks');
      const data = await res.json();
      if (data.tasks) {
        setTasks(data.tasks);
      }
    } catch (err) {
      console.error('Failed to load tasks:', err);
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: taskTitle,
          vpsId: targetVps,
          script: taskScript,
        }),
      });
      await res.json();
      setIsModalOpen(false);
      loadTasks();
    } catch (err) {
      console.error('Failed to create task:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <ListTodo className="h-6 w-6 text-cyan-400" />
            Background Task Engine & Long Jobs
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Asynchronous task queue for long-running upgrades, backup rotations, and automated fleet scripts.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadTasks}
            className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-300 hover:text-white"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 rounded-xl bg-cyan-600 px-4 py-2 text-xs font-bold text-white hover:bg-cyan-500 shadow-md"
          >
            <Plus className="h-4 w-4" />
            Dispatch New Task
          </button>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-4">
        {tasks.length === 0 ? (
          <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-12 text-center text-xs text-slate-500">
            No background jobs executed yet. Click "Dispatch New Task" to run long jobs asynchronously.
          </div>
        ) : (
          tasks.map((task) => (
            <div
              key={task.id}
              className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-3"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-xl font-bold ${
                      task.status === 'completed'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : task.status === 'failed'
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 animate-pulse'
                    }`}
                  >
                    {task.status === 'completed' ? (
                      <CheckCircle2 className="h-4 w-4" />
                    ) : task.status === 'failed' ? (
                      <XCircle className="h-4 w-4" />
                    ) : (
                      <Clock className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-sm">{task.title}</h3>
                    <p className="font-mono text-xs text-slate-400">
                      Target: <strong className="text-slate-200">{task.vpsName}</strong> • Started {new Date(task.createdAt).toLocaleTimeString()}
                    </p>
                  </div>
                </div>

                <span
                  className={`rounded-full px-2.5 py-0.5 font-mono text-[10px] font-semibold ${
                    task.status === 'completed'
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : task.status === 'failed'
                      ? 'bg-rose-500/20 text-rose-300'
                      : 'bg-cyan-500/20 text-cyan-300'
                  }`}
                >
                  {task.status.toUpperCase()}
                </span>
              </div>

              {/* Progress bar */}
              <div>
                <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
                  <span>Progress</span>
                  <span>{task.progress}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ${
                      task.status === 'completed'
                        ? 'bg-emerald-500'
                        : task.status === 'failed'
                        ? 'bg-rose-500'
                        : 'bg-cyan-500'
                    }`}
                    style={{ width: `${task.progress}%` }}
                  />
                </div>
              </div>

              {/* Logs Box */}
              {task.logs && task.logs.length > 0 && (
                <div className="rounded-xl border border-slate-800/80 bg-slate-950 p-3 font-mono text-xs text-slate-300 max-h-36 overflow-y-auto">
                  {task.logs.map((line, idx) => (
                    <div key={idx} className="whitespace-pre-wrap">{line}</div>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Dispatch Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-2xl">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Play className="h-4 w-4 text-cyan-400" />
              Dispatch Long-Running Job
            </h2>
            <form onSubmit={handleCreateTask} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-300">Job Title</label>
                <input
                  type="text"
                  required
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-300">Target VPS</label>
                <select
                  value={targetVps}
                  onChange={(e) => setTargetVps(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                >
                  {servers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.host})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-300">Execution Shell Script</label>
                <textarea
                  rows={4}
                  required
                  value={taskScript}
                  onChange={(e) => setTaskScript(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 p-3 font-mono text-[11px] text-cyan-300 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="rounded-xl bg-cyan-600 px-5 py-2 text-xs font-bold text-white hover:bg-cyan-500"
                >
                  {loading ? 'Queuing...' : 'Launch Job'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
