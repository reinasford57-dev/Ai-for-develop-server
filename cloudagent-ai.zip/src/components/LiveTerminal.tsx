import React, { useState, useRef, useEffect } from 'react';
import { Terminal, Send, Trash2, Copy, Check, Server, CornerDownLeft, Play } from 'lucide-react';
import { VPS } from '../types.js';

interface LiveTerminalProps {
  servers: VPS[];
  selectedVpsId?: string;
  setSelectedVpsId: (id: string) => void;
}

interface TerminalLog {
  id: string;
  command: string;
  output: string;
  stderr?: string;
  exitCode: number;
  durationMs: number;
  timestamp: string;
}

export const LiveTerminal: React.FC<LiveTerminalProps> = ({
  servers,
  selectedVpsId,
  setSelectedVpsId,
}) => {
  const [command, setCommand] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [logs, setLogs] = useState<TerminalLog[]>([
    {
      id: 'init-log-01',
      command: 'uname -a && uptime',
      output: 'Linux cloudops-edge 6.8.0-45-generic #45-Ubuntu SMP PREEMPT_DYNAMIC x86_64 GNU/Linux\n 19:55:00 up 28 days, 14:32, 1 user, load average: 0.34, 0.42, 0.39',
      exitCode: 0,
      durationMs: 42,
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);
  const [executing, setExecuting] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const currentVps = servers.find((s) => s.id === selectedVpsId) || servers[0];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleExecute = async (cmdToRun?: string) => {
    const cmd = (cmdToRun || command).trim();
    if (!cmd || executing || !currentVps) return;

    setCommand('');
    setHistory((prev) => [cmd, ...prev]);
    setHistoryIndex(-1);
    setExecuting(true);

    const logEntry: TerminalLog = {
      id: `term-${Date.now()}`,
      command: cmd,
      output: '',
      exitCode: 0,
      durationMs: 0,
      timestamp: new Date().toLocaleTimeString(),
    };

    try {
      const res = await fetch('/api/terminal/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vpsId: currentVps.id,
          command: cmd,
        }),
      });

      const data = await res.json();
      logEntry.output = data.stdout || '';
      logEntry.stderr = data.stderr || '';
      logEntry.exitCode = data.exitCode ?? 0;
      logEntry.durationMs = data.durationMs ?? 0;
      setLogs((prev) => [...prev, logEntry]);
    } catch (err: any) {
      logEntry.stderr = `Client execution error: ${err.message}`;
      logEntry.exitCode = 255;
      setLogs((prev) => [...prev, logEntry]);
    } finally {
      setExecuting(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length > 0 && historyIndex < history.length - 1) {
        const nextIdx = historyIndex + 1;
        setHistoryIndex(nextIdx);
        setCommand(history[nextIdx]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const prevIdx = historyIndex - 1;
        setHistoryIndex(prevIdx);
        setCommand(history[prevIdx]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setCommand('');
      }
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const quickCommands = [
    { label: 'df -h', cmd: 'df -h' },
    { label: 'free -m', cmd: 'free -m' },
    { label: 'top procs', cmd: 'ps aux --sort=-%cpu | head -n 10' },
    { label: 'systemctl status nginx', cmd: 'systemctl status nginx' },
    { label: 'docker ps', cmd: 'docker ps -a' },
    { label: 'ss -tulpn', cmd: 'ss -tulpn' },
    { label: 'ufw status', cmd: 'ufw status' },
    { label: 'nginx error log', cmd: 'tail -n 25 /var/log/nginx/error.log' },
  ];

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col bg-slate-950 p-4 sm:p-6">
      {/* Terminal Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-t-2xl border-x border-t border-slate-800 bg-slate-900 px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <span className="h-3 w-3 rounded-full bg-rose-500/80" />
            <span className="h-3 w-3 rounded-full bg-amber-500/80" />
            <span className="h-3 w-3 rounded-full bg-emerald-500/80" />
          </div>
          <div className="flex items-center gap-2 pl-2 text-xs font-mono font-medium text-slate-300">
            <Terminal className="h-4 w-4 text-cyan-400" />
            <span>Interactive Console:</span>
            <select
              value={selectedVpsId || currentVps?.id}
              onChange={(e) => setSelectedVpsId(e.target.value)}
              className="rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-1 text-xs text-white focus:border-cyan-500 focus:outline-none"
            >
              {servers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.host})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setLogs([])}
            className="flex items-center gap-1 rounded-lg border border-slate-700 px-2.5 py-1 text-xs font-medium text-slate-400 hover:text-white"
            title="Clear Terminal Output"
          >
            <Trash2 className="h-3.5 w-3.5" />
            Clear
          </button>
        </div>
      </div>

      {/* Quick Command Toolbar */}
      <div className="flex items-center gap-1.5 overflow-x-auto border-x border-slate-800 bg-slate-900/60 px-4 py-2 text-xs">
        <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider shrink-0 mr-1">
          Quick:
        </span>
        {quickCommands.map((qc) => (
          <button
            key={qc.cmd}
            onClick={() => handleExecute(qc.cmd)}
            disabled={executing}
            className="shrink-0 rounded-md border border-slate-800 bg-slate-950 px-2 py-0.5 font-mono text-[11px] text-cyan-400 hover:border-cyan-500/40 hover:bg-slate-900 disabled:opacity-50"
          >
            {qc.label}
          </button>
        ))}
      </div>

      {/* Terminal Viewport */}
      <div className="flex-1 overflow-y-auto border-x border-slate-800 bg-slate-950 p-4 font-mono text-xs leading-relaxed text-slate-300">
        {logs.map((log) => (
          <div key={log.id} className="mb-4 group">
            <div className="flex items-center justify-between text-[11px] text-slate-500 pb-1">
              <div className="flex items-center gap-2">
                <span className="text-emerald-400 font-bold">{currentVps?.username}@{currentVps?.name}:~$</span>
                <span className="text-white font-semibold">{log.command}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-slate-500">{log.durationMs}ms</span>
                <span
                  className={`rounded px-1 text-[9px] font-bold ${
                    log.exitCode === 0 ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'
                  }`}
                >
                  exit {log.exitCode}
                </span>
                <button
                  onClick={() => copyToClipboard(log.output || log.stderr || '', log.id)}
                  className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-white"
                  title="Copy output"
                >
                  {copiedId === log.id ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                </button>
              </div>
            </div>

            {log.output && (
              <pre className="whitespace-pre-wrap rounded bg-slate-900/40 p-2.5 text-slate-200 overflow-x-auto selection:bg-cyan-500/30">
                {log.output}
              </pre>
            )}

            {log.stderr && (
              <pre className="mt-1 whitespace-pre-wrap rounded bg-rose-950/30 border border-rose-900/40 p-2.5 text-rose-300 overflow-x-auto">
                {log.stderr}
              </pre>
            )}
          </div>
        ))}

        {executing && (
          <div className="flex items-center gap-2 text-cyan-400 text-xs py-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <span>Executing command on {currentVps?.name}...</span>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Terminal Input Box */}
      <div className="rounded-b-2xl border-x border-b border-slate-800 bg-slate-900 p-3">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleExecute();
          }}
          className="flex items-center gap-2 font-mono text-xs"
        >
          <span className="text-emerald-400 font-bold shrink-0">{currentVps?.username || 'root'}@vps:~$</span>
          <input
            ref={inputRef}
            type="text"
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={executing}
            placeholder="Type Linux shell command and press Enter (Up/Down for history)..."
            className="flex-1 bg-transparent text-white placeholder-slate-600 focus:outline-none"
            autoFocus
          />
          <button
            type="submit"
            disabled={!command.trim() || executing}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-cyan-600 text-white hover:bg-cyan-500 disabled:opacity-40"
            title="Execute"
          >
            <CornerDownLeft className="h-4 w-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
