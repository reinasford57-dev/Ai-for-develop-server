import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Bot, 
  User, 
  Terminal, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  ShieldAlert, 
  RotateCcw, 
  Plus, 
  Trash2, 
  ChevronRight, 
  ChevronDown, 
  FileCode, 
  Sparkles,
  Server,
  StopCircle
} from 'lucide-react';
import { VPS, ChatSession, ChatMessage, ToolInvocation, PlanStep } from '../types.js';

interface AgentChatProps {
  servers: VPS[];
  selectedVpsId?: string;
  setSelectedVpsId: (id: string) => void;
  onRefreshServers: () => void;
}

export const AgentChat: React.FC<AgentChatProps> = ({
  servers,
  selectedVpsId,
  setSelectedVpsId,
  onRefreshServers,
}) => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [prompt, setPrompt] = useState<string>('');
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  const [streamingText, setStreamingText] = useState<string>('');
  const [streamingPlan, setStreamingPlan] = useState<{ summary: string; steps: PlanStep[] } | null>(null);
  const [streamingTools, setStreamingTools] = useState<ToolInvocation[]>([]);
  const [expandedTools, setExpandedTools] = useState<Record<string, boolean>>({});
  const [diffModal, setDiffModal] = useState<{ filePath: string; before: string; after: string } | null>(null);
  const [pendingApproval, setPendingApproval] = useState<{
    id: string;
    tool: string;
    args: Record<string, any>;
    vpsName: string;
    reason?: string;
  } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const selectedServer = servers.find((s) => s.id === selectedVpsId) || servers[0];

  // Load chat sessions on mount
  useEffect(() => {
    loadSessions();
  }, []);

  const loadSessions = async () => {
    try {
      const res = await fetch('/api/chat/sessions');
      const data = await res.json();
      if (data.sessions && data.sessions.length > 0) {
        setSessions(data.sessions);
        setActiveSessionId(data.sessions[0].id);
        setMessages(data.sessions[0].messages || []);
      } else {
        createNewSession();
      }
    } catch (err) {
      console.error('Failed to load chat sessions:', err);
    }
  };

  const createNewSession = async () => {
    try {
      const res = await fetch('/api/chat/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: `Mission ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
          targetVpsId: selectedServer?.id,
        }),
      });
      const data = await res.json();
      if (data.session) {
        setSessions((prev) => [data.session, ...prev]);
        setActiveSessionId(data.session.id);
        setMessages([]);
      }
    } catch (err) {
      console.error('Failed to create session:', err);
    }
  };

  const selectSession = async (sessionId: string) => {
    setActiveSessionId(sessionId);
    try {
      const res = await fetch(`/api/chat/sessions/${sessionId}`);
      const data = await res.json();
      if (data.session) {
        setMessages(data.session.messages || []);
      }
    } catch (err) {
      console.error('Failed to load session details:', err);
    }
  };

  const deleteSession = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await fetch(`/api/chat/sessions/${sessionId}`, { method: 'DELETE' });
      const remaining = sessions.filter((s) => s.id !== sessionId);
      setSessions(remaining);
      if (activeSessionId === sessionId) {
        if (remaining.length > 0) {
          selectSession(remaining[0].id);
        } else {
          createNewSession();
        }
      }
    } catch (err) {
      console.error('Failed to delete session:', err);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamingText, streamingTools, pendingApproval]);

  const handleSendMessage = async (textToSend?: string) => {
    const input = (textToSend || prompt).trim();
    if (!input || isStreaming) return;

    setPrompt('');
    setIsStreaming(true);
    setStreamingText('');
    setStreamingPlan(null);
    setStreamingTools([]);
    setPendingApproval(null);

    // Add user message optimistically
    const optimisticUserMsg: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      role: 'user',
      content: input,
      timestamp: new Date().toISOString(),
      targetVpsId: selectedServer?.id,
    };
    setMessages((prev) => [...prev, optimisticUserMsg]);

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: activeSessionId,
          prompt: input,
          targetVpsId: selectedServer?.id,
        }),
      });

      if (!response.body) {
        throw new Error('ReadableStream not supported on response.');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.trim()) continue;
          const matchEvent = line.match(/^event:\s*(.+)$/m);
          const matchData = line.match(/^data:\s*(.+)$/m);

          if (matchEvent && matchData) {
            const eventType = matchEvent[1].trim();
            const eventData = JSON.parse(matchData[1].trim());

            if (eventType === 'plan') {
              setStreamingPlan(eventData);
            } else if (eventType === 'chunk') {
              setStreamingText((prev) => prev + eventData.text);
            } else if (eventType === 'tool_call') {
              setStreamingTools((prev) => {
                const existing = prev.findIndex((t) => t.id === eventData.id);
                if (existing >= 0) return prev;
                return [...prev, eventData];
              });
            } else if (eventType === 'approval_required') {
              setPendingApproval(eventData);
            } else if (eventType === 'tool_result') {
              setStreamingTools((prev) =>
                prev.map((t) =>
                  t.id === eventData.id
                    ? {
                        ...t,
                        status: eventData.success ? 'success' : 'failed',
                        output: eventData.output,
                        exitCode: eventData.exitCode,
                        diff: eventData.diff,
                      }
                    : t
                )
              );
            } else if (eventType === 'complete') {
              // Reload session from db to ensure pristine persistence
              if (activeSessionId) {
                setTimeout(() => selectSession(activeSessionId), 400);
              }
              onRefreshServers();
            }
          }
        }
      }
    } catch (err: any) {
      console.error('Chat stream error:', err);
      setStreamingText((prev) => prev + `\n\n[Connection Error: ${err.message}]`);
    } finally {
      setIsStreaming(false);
    }
  };

  const handleToolApproval = async (approved: boolean) => {
    if (!pendingApproval) return;
    const approvalData = { ...pendingApproval };
    setPendingApproval(null);

    try {
      const res = await fetch('/api/chat/approve-tool', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vpsId: selectedServer?.id,
          tool: approvalData.tool,
          args: approvalData.args,
          approved,
        }),
      });
      const data = await res.json();

      if (approved && data.result) {
        setStreamingTools((prev) =>
          prev.map((t) =>
            t.id === approvalData.id
              ? {
                  ...t,
                  status: data.result.success ? 'success' : 'failed',
                  output: data.result.output,
                  exitCode: data.result.exitCode,
                  diff: data.result.diff,
                }
              : t
          )
        );
      }
      onRefreshServers();
    } catch (err) {
      console.error('Failed to submit tool approval:', err);
    }
  };

  const toggleToolExpanded = (id: string) => {
    setExpandedTools((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const quickPrompts = [
    { label: 'System Health & Top Processes', text: 'Run full system diagnostics and check top 5 CPU & memory processes on this VPS.' },
    { label: 'Check Nginx & Error Logs', text: 'Inspect Nginx service status and analyze the latest error logs from /var/log/nginx/error.log.' },
    { label: 'Docker Container Audit', text: 'List all running and stopped Docker containers and check their health status.' },
    { label: 'Security & Firewall Inspection', text: 'Check active UFW firewall status, open listening ports, and review sshd authentication log entries.' },
  ];

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col lg:flex-row bg-slate-950">
      {/* Session History Drawer (Desktop Sidebar) */}
      <div className="hidden lg:flex w-64 flex-col border-r border-slate-800/80 bg-slate-950/40 p-3">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Conversations</span>
          <button
            onClick={createNewSession}
            className="flex items-center gap-1 rounded-md bg-cyan-600/20 px-2 py-1 text-xs font-medium text-cyan-400 hover:bg-cyan-600/30 transition-colors"
          >
            <Plus className="h-3.5 w-3.5" />
            New
          </button>
        </div>
        <div className="mt-2 flex-1 space-y-1 overflow-y-auto pr-1">
          {sessions.map((s) => {
            const isActive = s.id === activeSessionId;
            return (
              <div
                key={s.id}
                onClick={() => selectSession(s.id)}
                className={`group flex items-center justify-between rounded-lg px-2.5 py-2 text-xs cursor-pointer transition-colors ${
                  isActive
                    ? 'bg-slate-800 text-white font-medium border border-slate-700'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`}
              >
                <span className="truncate pr-2">{s.title || 'Untitled Session'}</span>
                <button
                  onClick={(e) => deleteSession(s.id, e)}
                  className="opacity-0 group-hover:opacity-100 p-0.5 text-slate-500 hover:text-rose-400 transition-opacity"
                  title="Delete conversation"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Chat & Execution Area */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top Target VPS Notification Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 bg-slate-900/40 px-4 py-2.5 text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <Server className="h-3.5 w-3.5 text-cyan-400" />
            <span>Target Node:</span>
            <span className="font-mono font-semibold text-white">{selectedServer?.name}</span>
            <span className="font-mono text-slate-400">({selectedServer?.host}:{selectedServer?.port})</span>
            {selectedServer?.isDemo && (
              <span className="rounded bg-amber-500/10 px-1.5 py-0.5 text-[10px] font-mono text-amber-300 border border-amber-500/20">
                Sandbox Mode
              </span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-400">Model: <strong className="text-slate-200 font-mono">gemini-3.8-flash</strong></span>
            <button
              onClick={createNewSession}
              className="lg:hidden flex items-center gap-1 text-[11px] text-cyan-400 hover:underline"
            >
              <Plus className="h-3 w-3" /> New Task
            </button>
          </div>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-5">
          {messages.length === 0 && !isStreaming && (
            <div className="mx-auto my-8 max-w-2xl rounded-2xl border border-slate-800 bg-slate-900/50 p-6 text-center">
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-cyan-600 to-indigo-600 text-white shadow-lg shadow-cyan-950/50">
                <Sparkles className="h-6 w-6" />
              </div>
              <h2 className="text-lg font-bold text-white">Autonomous Cloud Operations Agent</h2>
              <p className="mt-1 text-xs text-slate-400 max-w-md mx-auto">
                Issue natural language instructions to inspect, diagnose, repair, and manage your Linux VPS fleet with real tool execution and rollback safety.
              </p>

              {/* Quick Prompt Cards */}
              <div className="mt-6 grid grid-cols-1 gap-2.5 sm:grid-cols-2 text-left">
                {quickPrompts.map((qp, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(qp.text)}
                    className="group rounded-xl border border-slate-800 bg-slate-950/70 p-3 hover:border-cyan-500/40 hover:bg-slate-900 transition-all"
                  >
                    <div className="text-xs font-semibold text-cyan-400 group-hover:text-cyan-300 flex items-center gap-1.5">
                      <Terminal className="h-3.5 w-3.5" />
                      {qp.label}
                    </div>
                    <div className="mt-1 text-[11px] text-slate-400 line-clamp-2">
                      {qp.text}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Render Persistent Messages */}
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'assistant' && (
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-cyan-600 text-white shadow-sm">
                  <Bot className="h-4 w-4" />
                </div>
              )}

              <div className={`max-w-3xl space-y-3 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                {/* Plan Visualizer Card */}
                {msg.plan && (
                  <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/20 p-3.5 text-xs">
                    <div className="flex items-center gap-2 font-semibold text-indigo-300 mb-2">
                      <Clock className="h-4 w-4" />
                      <span>Autonomous Operational Plan</span>
                    </div>
                    <p className="text-[11px] text-indigo-200/80 mb-2.5 font-medium">{msg.plan.summary}</p>
                    <div className="space-y-1.5">
                      {msg.plan.steps.map((st) => (
                        <div key={st.id} className="flex items-center gap-2 text-[11px]">
                          <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-indigo-900/60 font-mono text-[10px] text-indigo-300">
                            {st.id}
                          </span>
                          <span className="text-slate-300 flex-1">{st.title}</span>
                          <span className="rounded bg-slate-800/80 px-1.5 py-0.5 font-mono text-[9px] text-emerald-400">
                            Done
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Tool Invocations Accordion */}
                {msg.toolInvocations && msg.toolInvocations.length > 0 && (
                  <div className="space-y-2">
                    {msg.toolInvocations.map((t) => {
                      const isExpanded = !!expandedTools[t.id];
                      return (
                        <div
                          key={t.id}
                          className="rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 text-xs font-mono"
                        >
                          <div
                            onClick={() => toggleToolExpanded(t.id)}
                            className="flex items-center justify-between cursor-pointer select-none"
                          >
                            <div className="flex items-center gap-2">
                              {isExpanded ? <ChevronDown className="h-3.5 w-3.5 text-slate-400" /> : <ChevronRight className="h-3.5 w-3.5 text-slate-400" />}
                              <Terminal className="h-3.5 w-3.5 text-cyan-400" />
                              <span className="font-semibold text-slate-200">{t.tool}</span>
                              <span className="text-[10px] text-slate-500">({t.vpsName})</span>
                            </div>
                            <div className="flex items-center gap-2">
                              {t.diff && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setDiffModal(t.diff!);
                                  }}
                                  className="flex items-center gap-1 rounded bg-indigo-500/20 px-1.5 py-0.5 text-[10px] text-indigo-300 hover:bg-indigo-500/30"
                                >
                                  <FileCode className="h-3 w-3" />
                                  View Diff
                                </button>
                              )}
                              <span
                                className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${
                                  t.status === 'success'
                                    ? 'bg-emerald-500/20 text-emerald-400'
                                    : 'bg-rose-500/20 text-rose-400'
                                }`}
                              >
                                {t.status === 'success' ? 'Exit: 0' : `Exit: ${t.exitCode ?? 1}`}
                              </span>
                            </div>
                          </div>

                          {/* Expanded Tool Output */}
                          {isExpanded && (
                            <div className="mt-2.5 border-t border-slate-800/80 pt-2 space-y-2">
                              <div>
                                <span className="text-[10px] text-slate-400 font-sans">Parameters:</span>
                                <pre className="mt-0.5 overflow-x-auto rounded bg-slate-950 p-2 text-[11px] text-cyan-300">
                                  {JSON.stringify(t.args, null, 2)}
                                </pre>
                              </div>
                              {t.output && (
                                <div>
                                  <span className="text-[10px] text-slate-400 font-sans">Terminal Output:</span>
                                  <pre className="mt-0.5 max-h-48 overflow-y-auto rounded bg-slate-950 p-2 text-[11px] text-slate-300 leading-relaxed">
                                    {t.output}
                                  </pre>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Message Text Bubble */}
                <div
                  className={`rounded-2xl p-4 text-xs leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white'
                      : 'border border-slate-800 bg-slate-900/90 text-slate-200'
                  }`}
                >
                  <div className="whitespace-pre-wrap font-sans space-y-2">
                    {msg.content}
                  </div>
                  <div className="mt-1 text-right text-[10px] opacity-60 font-mono">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>

              {msg.role === 'user' && (
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-800 text-slate-300">
                  <User className="h-4 w-4" />
                </div>
              )}
            </div>
          ))}

          {/* Active Streaming Message */}
          {isStreaming && (
            <div className="flex gap-3 justify-start">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-cyan-600 text-white animate-pulse">
                <Bot className="h-4 w-4" />
              </div>

              <div className="max-w-3xl space-y-3">
                {/* Streaming Plan */}
                {streamingPlan && (
                  <div className="rounded-xl border border-cyan-500/30 bg-cyan-950/20 p-3.5 text-xs animate-in fade-in">
                    <div className="flex items-center gap-2 font-semibold text-cyan-300 mb-2">
                      <Clock className="h-4 w-4 animate-spin" />
                      <span>Executing Autonomous Plan</span>
                    </div>
                    <p className="text-[11px] text-cyan-200/80 mb-2 font-medium">{streamingPlan.summary}</p>
                    <div className="space-y-1.5">
                      {streamingPlan.steps.map((st) => (
                        <div key={st.id} className="flex items-center gap-2 text-[11px]">
                          <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-cyan-900/60 font-mono text-[10px] text-cyan-300">
                            {st.id}
                          </span>
                          <span className="text-slate-300 flex-1">{st.title}</span>
                          <span className="rounded bg-cyan-500/20 px-1.5 py-0.5 font-mono text-[9px] text-cyan-300">
                            {st.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Streaming Tools */}
                {streamingTools.map((t) => (
                  <div
                    key={t.id}
                    className="rounded-xl border border-cyan-800/60 bg-slate-900/90 p-2.5 text-xs font-mono"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Terminal className="h-3.5 w-3.5 text-cyan-400" />
                        <span className="font-semibold text-white">{t.tool}</span>
                        <span className="text-[10px] text-slate-500">({t.vpsName})</span>
                      </div>
                      <span
                        className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${
                          t.status === 'success'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : t.status === 'failed'
                            ? 'bg-rose-500/20 text-rose-400'
                            : 'bg-amber-500/20 text-amber-300 animate-pulse'
                        }`}
                      >
                        {t.status === 'running' ? 'Running...' : t.status}
                      </span>
                    </div>
                    {t.output && (
                      <pre className="mt-2 max-h-36 overflow-y-auto rounded bg-slate-950 p-2 text-[11px] text-slate-300">
                        {t.output}
                      </pre>
                    )}
                  </div>
                ))}

                {/* Pending High-Risk Approval Banner */}
                {pendingApproval && (
                  <div className="rounded-xl border-2 border-amber-500/50 bg-amber-950/30 p-4 text-xs shadow-lg">
                    <div className="flex items-center gap-2 font-bold text-amber-300 text-sm">
                      <ShieldAlert className="h-5 w-5 text-amber-400" />
                      <span>High-Risk Operation Requires Authorization</span>
                    </div>
                    <p className="mt-1 text-slate-200">
                      The AI Agent requests execution of <strong className="text-white font-mono">{pendingApproval.tool}</strong> on server{' '}
                      <strong className="text-white">{pendingApproval.vpsName}</strong>:
                    </p>
                    {pendingApproval.reason && (
                      <div className="mt-2 rounded bg-amber-900/40 p-2 text-amber-200 font-mono text-[11px]">
                        Reason: {pendingApproval.reason}
                      </div>
                    )}
                    <pre className="mt-2 overflow-x-auto rounded bg-slate-950 p-2 text-[10px] font-mono text-cyan-300">
                      {JSON.stringify(pendingApproval.args, null, 2)}
                    </pre>
                    <div className="mt-3 flex items-center justify-end gap-2.5">
                      <button
                        onClick={() => handleToolApproval(false)}
                        className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:bg-slate-700"
                      >
                        Reject Action
                      </button>
                      <button
                        onClick={() => handleToolApproval(true)}
                        className="rounded-lg bg-amber-500 px-3.5 py-1.5 text-xs font-bold text-slate-950 hover:bg-amber-400 transition-colors shadow-sm"
                      >
                        Authorize & Execute
                      </button>
                    </div>
                  </div>
                )}

                {/* Streaming Assistant Text */}
                {streamingText && (
                  <div className="rounded-2xl border border-cyan-500/30 bg-slate-900/90 p-4 text-xs text-slate-200">
                    <div className="whitespace-pre-wrap font-sans space-y-2">
                      {streamingText}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="border-t border-slate-800 bg-slate-950/90 p-3 sm:p-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={`Instruct AI agent on ${selectedServer?.name || 'VPS'} (e.g., "Check why memory is 85%", "Install certbot", "Review UFW rules")...`}
              disabled={isStreaming}
              className="flex-1 rounded-xl border border-slate-800 bg-slate-900/90 px-4 py-3 text-xs text-white placeholder-slate-500 transition-colors focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={!prompt.trim() || isStreaming}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 text-white transition-all hover:opacity-90 disabled:opacity-40"
              title="Send instruction to AI Agent"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Diff Modal */}
      {diffModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
          <div className="flex max-h-[85vh] w-full max-w-4xl flex-col rounded-2xl border border-slate-800 bg-slate-950 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <FileCode className="h-4 w-4 text-cyan-400" />
                <span>File Modification Diff: <strong className="font-mono text-cyan-300">{diffModal.filePath}</strong></span>
              </div>
              <button
                onClick={() => setDiffModal(null)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 overflow-y-auto flex-1 font-mono text-[11px]">
              <div>
                <div className="text-xs font-semibold text-rose-400 mb-1">Original Content (Before):</div>
                <pre className="rounded-lg border border-rose-950 bg-rose-950/20 p-3 text-rose-200 overflow-x-auto h-72">
                  {diffModal.before || '(File was created fresh or was empty)'}
                </pre>
              </div>
              <div>
                <div className="text-xs font-semibold text-emerald-400 mb-1">New Content (After):</div>
                <pre className="rounded-lg border border-emerald-950 bg-emerald-950/20 p-3 text-emerald-200 overflow-x-auto h-72">
                  {diffModal.after}
                </pre>
              </div>
            </div>
            <div className="border-t border-slate-800 px-5 py-3 text-right">
              <button
                onClick={() => setDiffModal(null)}
                className="rounded-lg bg-slate-800 px-4 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700"
              >
                Close Diff
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
