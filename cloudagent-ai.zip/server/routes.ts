import { Router, Request, Response } from 'express';
import { db, VPS, ChatSession, ChatMessage } from './db.js';
import { encryptCredential, maskSecret } from './crypto.js';
import { SSHManager } from './ssh.js';
import { AgentEngine } from './agent.js';
import { executeTool } from './tools.js';

export const apiRouter = Router();

// Helper to sanitize VPS before sending to client
function sanitizeVpsForClient(vps: VPS) {
  return {
    ...vps,
    encryptedSecret: maskSecret(vps.encryptedSecret),
    encryptedPassphrase: vps.encryptedPassphrase ? '********' : undefined,
  };
}

// ==========================================
// 1. VPS Management Endpoints
// ==========================================

// List all servers
apiRouter.get('/servers', (req: Request, res: Response) => {
  const servers = db.getServers().map(sanitizeVpsForClient);
  res.json({ servers });
});

// Add new server
apiRouter.post('/servers', async (req: Request, res: Response) => {
  try {
    const { name, host, port, username, authType, secret, passphrase, tags } = req.body;

    if (!name || !host || !username || !secret) {
      return res.status(400).json({ error: 'Name, host, username, and secret (key/password) are required.' });
    }

    const newVps: VPS = {
      id: `vps-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      host: host.trim(),
      port: parseInt(port, 10) || 22,
      username: username.trim(),
      authType: authType === 'password' ? 'password' : 'key',
      encryptedSecret: encryptCredential(secret),
      encryptedPassphrase: passphrase ? encryptCredential(passphrase) : undefined,
      tags: Array.isArray(tags) ? tags : ['default'],
      status: 'untested',
      lastChecked: new Date().toISOString(),
    };

    // Test connection immediately
    const testResult = await SSHManager.testConnection(newVps);
    if (testResult.success) {
      newVps.status = 'online';
      newVps.fingerprint = testResult.fingerprint;
      newVps.osInfo = testResult.osInfo;
      newVps.metrics = testResult.metrics;
    } else {
      newVps.status = 'offline';
    }

    db.saveServer(newVps);

    db.addAuditLog({
      vpsId: newVps.id,
      vpsName: newVps.name,
      action: 'SERVER_REGISTERED',
      actor: 'user',
      details: `Added new server ${newVps.name} (${newVps.host}:${newVps.port}). Status: ${newVps.status}`,
      status: testResult.success ? 'success' : 'warning',
    });

    res.status(201).json({
      server: sanitizeVpsForClient(newVps),
      connectionTest: testResult,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to add VPS' });
  }
});

// Update server
apiRouter.put('/servers/:id', async (req: Request, res: Response) => {
  try {
    const vps = db.getServerById(req.params.id);
    if (!vps) {
      return res.status(404).json({ error: 'Server not found' });
    }

    const { name, host, port, username, authType, secret, passphrase, tags } = req.body;

    if (name) vps.name = name.trim();
    if (host) vps.host = host.trim();
    if (port) vps.port = parseInt(port, 10) || 22;
    if (username) vps.username = username.trim();
    if (authType) vps.authType = authType;
    if (secret && !secret.includes('***')) {
      vps.encryptedSecret = encryptCredential(secret);
    }
    if (passphrase) {
      vps.encryptedPassphrase = encryptCredential(passphrase);
    }
    if (Array.isArray(tags)) vps.tags = tags;

    db.saveServer(vps);
    res.json({ server: sanitizeVpsForClient(vps) });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Delete server
apiRouter.delete('/servers/:id', (req: Request, res: Response) => {
  const vps = db.getServerById(req.params.id);
  if (!vps) {
    return res.status(404).json({ error: 'Server not found' });
  }

  db.deleteServer(req.params.id);
  db.addAuditLog({
    vpsId: vps.id,
    vpsName: vps.name,
    action: 'SERVER_DELETED',
    actor: 'user',
    details: `Deleted server ${vps.name} (${vps.host})`,
    status: 'success',
  });

  res.json({ success: true });
});

// Test server connection
apiRouter.post('/servers/:id/test', async (req: Request, res: Response) => {
  const vps = db.getServerById(req.params.id);
  if (!vps) {
    return res.status(404).json({ error: 'Server not found' });
  }

  const result = await SSHManager.testConnection(vps);
  vps.status = result.success ? 'online' : 'offline';
  vps.lastChecked = new Date().toISOString();
  if (result.fingerprint) vps.fingerprint = result.fingerprint;
  if (result.osInfo) vps.osInfo = result.osInfo;
  if (result.metrics) vps.metrics = result.metrics;

  db.saveServer(vps);
  res.json({
    success: result.success,
    status: vps.status,
    metrics: vps.metrics,
    osInfo: vps.osInfo,
    error: result.error,
  });
});

// Refresh server metrics
apiRouter.get('/servers/:id/metrics', async (req: Request, res: Response) => {
  const vps = db.getServerById(req.params.id);
  if (!vps) {
    return res.status(404).json({ error: 'Server not found' });
  }

  const metrics = await SSHManager.collectLiveMetrics(vps);
  if (metrics) {
    vps.metrics = metrics;
    vps.lastChecked = new Date().toISOString();
    vps.status = 'online';
    db.saveServer(vps);
  }
  res.json({ metrics, status: vps.status });
});

// ==========================================
// 2. Chat & AI Agent Endpoints (SSE Stream)
// ==========================================

// List chat sessions
apiRouter.get('/chat/sessions', (req: Request, res: Response) => {
  res.json({ sessions: db.getSessions() });
});

// Create new chat session
apiRouter.post('/chat/sessions', (req: Request, res: Response) => {
  const { title, targetVpsId } = req.body;
  const newSession: ChatSession = {
    id: `session-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    title: title || 'New CloudOps Session',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    targetVpsId,
    messages: [],
  };

  db.saveSession(newSession);
  res.status(201).json({ session: newSession });
});

// Get session details
apiRouter.get('/chat/sessions/:id', (req: Request, res: Response) => {
  const session = db.getSessionById(req.params.id);
  if (!session) {
    return res.status(404).json({ error: 'Session not found' });
  }
  res.json({ session });
});

// Delete session
apiRouter.delete('/chat/sessions/:id', (req: Request, res: Response) => {
  const deleted = db.deleteSession(req.params.id);
  res.json({ success: deleted });
});

// SSE Streaming AI Agent Message
apiRouter.post('/chat/stream', async (req: Request, res: Response) => {
  const { sessionId, prompt, targetVpsId } = req.body;

  if (!prompt || !prompt.trim()) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  let session: ChatSession | undefined;
  if (sessionId) {
    session = db.getSessionById(sessionId);
  }

  if (!session) {
    session = {
      id: `session-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: prompt.slice(0, 32) + (prompt.length > 32 ? '...' : ''),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      targetVpsId,
      messages: [],
    };
    db.saveSession(session);
  }

  // Record user message
  const userMsg: ChatMessage = {
    id: `msg-${Date.now()}-user`,
    role: 'user',
    content: prompt,
    timestamp: new Date().toISOString(),
    targetVpsId: targetVpsId || session.targetVpsId,
  };
  session.messages.push(userMsg);
  session.updatedAt = new Date().toISOString();
  db.saveSession(session);

  // Set up SSE headers
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
  });

  const sendEvent = (event: string, data: any) => {
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  sendEvent('session_info', { sessionId: session.id });

  try {
    const agentResult = await AgentEngine.run({
      userPrompt: prompt,
      vpsId: targetVpsId || session.targetVpsId,
      history: session.messages.slice(0, -1),
      onEvent: (event) => {
        sendEvent(event.type, event.data);
      },
    });

    // Save assistant message to session
    const assistantMsg: ChatMessage = {
      id: `msg-${Date.now()}-assistant`,
      role: 'assistant',
      content: agentResult.message,
      timestamp: new Date().toISOString(),
      targetVpsId: targetVpsId || session.targetVpsId,
      plan: agentResult.plan,
      toolInvocations: agentResult.toolInvocations,
    };

    session.messages.push(assistantMsg);
    session.updatedAt = new Date().toISOString();
    db.saveSession(session);

    sendEvent('done', { messageId: assistantMsg.id });
    res.end();
  } catch (err: any) {
    console.error('SSE Agent error:', err);
    sendEvent('error', { message: err.message || 'Agent failed to run.' });
    res.end();
  }
});

// Approve and execute a paused tool invocation
apiRouter.post('/chat/approve-tool', async (req: Request, res: Response) => {
  try {
    const { vpsId, tool, args, approved } = req.body;
    const vps = db.getServerById(vpsId);

    if (!vps) {
      return res.status(404).json({ error: 'Target VPS not found' });
    }

    if (!approved) {
      db.addAuditLog({
        vpsId: vps.id,
        vpsName: vps.name,
        action: 'TOOL_APPROVAL_REJECTED',
        actor: 'user',
        details: `User rejected high-risk execution of ${tool}`,
        status: 'warning',
      });
      return res.json({ success: false, rejected: true, message: 'Action was rejected by user.' });
    }

    // Execute the approved tool
    const result = await executeTool(vps, tool, args);

    db.addAuditLog({
      vpsId: vps.id,
      vpsName: vps.name,
      action: 'TOOL_APPROVAL_GRANTED',
      actor: 'user',
      details: `User approved execution of ${tool}. Result exit code: ${result.exitCode}`,
      status: result.success ? 'success' : 'failed',
      exitCode: result.exitCode,
    });

    res.json({ success: result.success, result });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 3. Live Terminal API
// ==========================================

apiRouter.post('/terminal/exec', async (req: Request, res: Response) => {
  try {
    const { vpsId, command, timeoutSeconds } = req.body;
    if (!vpsId || !command) {
      return res.status(400).json({ error: 'vpsId and command are required' });
    }

    const vps = db.getServerById(vpsId);
    if (!vps) {
      return res.status(404).json({ error: 'Server not found' });
    }

    const result = await SSHManager.executeCommand(vps, command, {
      timeoutMs: (timeoutSeconds || 30) * 1000,
    });

    db.addAuditLog({
      vpsId: vps.id,
      vpsName: vps.name,
      action: 'TERMINAL_COMMAND',
      actor: 'user',
      details: command,
      status: result.exitCode === 0 ? 'success' : 'failed',
      exitCode: result.exitCode,
    });

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 4. Remote File Manager & Diff API
// ==========================================

// List files in directory
apiRouter.get('/files/list', async (req: Request, res: Response) => {
  const { vpsId, path } = req.query;
  if (!vpsId) {
    return res.status(400).json({ error: 'vpsId is required' });
  }
  const vps = db.getServerById(vpsId as string);
  if (!vps) {
    return res.status(404).json({ error: 'Server not found' });
  }

  const result = await SSHManager.listFiles(vps, (path as string) || '/');
  res.json(result);
});

// Read file content
apiRouter.get('/files/read', async (req: Request, res: Response) => {
  const { vpsId, filePath } = req.query;
  if (!vpsId || !filePath) {
    return res.status(400).json({ error: 'vpsId and filePath are required' });
  }
  const vps = db.getServerById(vpsId as string);
  if (!vps) {
    return res.status(404).json({ error: 'Server not found' });
  }

  const result = await SSHManager.readFile(vps, filePath as string, 500);
  res.json(result);
});

// Write file content (creates rollback backup snapshot)
apiRouter.post('/files/write', async (req: Request, res: Response) => {
  const { vpsId, filePath, content, description } = req.body;
  if (!vpsId || !filePath || content === undefined) {
    return res.status(400).json({ error: 'vpsId, filePath, and content are required' });
  }
  const vps = db.getServerById(vpsId);
  if (!vps) {
    return res.status(404).json({ error: 'Server not found' });
  }

  const result = await SSHManager.writeFile(vps, filePath, content, description);
  res.json(result);
});

// List backups for rollback
apiRouter.get('/files/backups', (req: Request, res: Response) => {
  const { vpsId, filePath } = req.query;
  const backups = db.getBackups(vpsId as string, filePath as string);
  res.json({ backups });
});

// Rollback to snapshot
apiRouter.post('/files/rollback', async (req: Request, res: Response) => {
  const { backupId } = req.body;
  const backup = db.getBackupById(backupId);
  if (!backup) {
    return res.status(404).json({ error: 'Backup not found' });
  }

  const vps = db.getServerById(backup.vpsId);
  if (!vps) {
    return res.status(404).json({ error: 'Associated server not found' });
  }

  const result = await SSHManager.writeFile(vps, backup.filePath, backup.content, `Restored from snapshot ${backup.id}`);
  res.json(result);
});

// ==========================================
// 5. Background Task Queue API
// ==========================================

apiRouter.get('/tasks', (req: Request, res: Response) => {
  res.json({ tasks: db.getTasks() });
});

apiRouter.post('/tasks', async (req: Request, res: Response) => {
  const { title, vpsId, script } = req.body;
  const vps = db.getServerById(vpsId);
  if (!vps) {
    return res.status(404).json({ error: 'Server not found' });
  }

  const task = db.saveTask({
    id: `task-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    title: title || 'Background Maintenance Job',
    vpsId: vps.id,
    vpsName: vps.name,
    status: 'running',
    progress: 10,
    logs: [`[${new Date().toLocaleTimeString()}] Task queued for execution on ${vps.name}`],
    createdAt: new Date().toISOString(),
  });

  // Execute asynchronously
  setTimeout(async () => {
    task.logs.push(`[${new Date().toLocaleTimeString()}] Starting command execution...`);
    task.progress = 40;
    db.saveTask(task);

    const res = await SSHManager.executeCommand(vps, script || 'sleep 3 && df -h && free -m');
    task.progress = 100;
    task.completedAt = new Date().toISOString();
    task.status = res.exitCode === 0 ? 'completed' : 'failed';
    task.logs.push(res.stdout || res.stderr);
    db.saveTask(task);
  }, 1000);

  res.status(202).json({ task });
});

// ==========================================
// 6. Audit & Settings API
// ==========================================

apiRouter.get('/audit', (req: Request, res: Response) => {
  res.json({ logs: db.getAuditLogs(100) });
});

apiRouter.get('/settings', (req: Request, res: Response) => {
  res.json({ settings: db.getSettings() });
});

apiRouter.put('/settings', (req: Request, res: Response) => {
  const updated = db.updateSettings(req.body);
  res.json({ settings: updated });
});
