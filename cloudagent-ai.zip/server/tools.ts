import { FunctionDeclaration, Type } from '@google/genai';
import { VPS, db } from './db.js';
import { SSHManager } from './ssh.js';

export interface ToolExecutionResult {
  tool: string;
  args: Record<string, any>;
  vpsId: string;
  vpsName: string;
  success: boolean;
  output: string;
  exitCode: number;
  durationMs: number;
  isHighRisk?: boolean;
  requiresApproval?: boolean;
  diff?: {
    filePath: string;
    before: string;
    after: string;
  };
}

/**
 * High-risk operation detection rules
 */
export function isOperationHighRisk(toolName: string, args: Record<string, any>): { isHighRisk: boolean; reason?: string } {
  if (toolName === 'write_file_safe') {
    const f = (args.filePath || '').toLowerCase();
    if (f.startsWith('/etc/') || f.startsWith('/boot/') || f.includes('shadow') || f.includes('sudoers')) {
      return { isHighRisk: true, reason: `Modifying sensitive system file: ${args.filePath}` };
    }
  }

  if (toolName === 'manage_service') {
    const action = (args.action || '').toLowerCase();
    const svc = (args.serviceName || '').toLowerCase();
    if (action === 'stop' || svc === 'ssh' || svc === 'sshd' || svc === 'ufw' || svc === 'networking') {
      return { isHighRisk: true, reason: `Altering critical service: ${args.action} on ${args.serviceName}` };
    }
  }

  if (toolName === 'manage_firewall') {
    return { isHighRisk: true, reason: `Modifying network firewall rules: ${args.action} ${args.rule || ''}` };
  }

  if (toolName === 'manage_package') {
    if (args.action === 'remove' || args.action === 'purge') {
      return { isHighRisk: true, reason: `Uninstalling system package: ${args.packageName}` };
    }
  }

  if (toolName === 'safe_exec_command') {
    const cmd = (args.command || '').trim().toLowerCase();
    if (
      cmd.includes('rm ') ||
      cmd.includes('iptables') ||
      cmd.includes('reboot') ||
      cmd.includes('shutdown') ||
      cmd.includes('fdisk') ||
      cmd.includes('dd ') ||
      cmd.includes('chmod -r 777')
    ) {
      return { isHighRisk: true, reason: `Executing potentially destructive command: ${args.command}` };
    }
  }

  return { isHighRisk: false };
}

/**
 * Tool Declarations for Gemini Function Calling
 */
export const toolDeclarations: FunctionDeclaration[] = [
  {
    name: 'system_diagnostics',
    description: 'Retrieve real-time comprehensive system diagnostics including OS, CPU, RAM, Disk, Uptime, Load Average, and listening network ports.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        includeNetworkPorts: {
          type: Type.BOOLEAN,
          description: 'Whether to include active listening TCP/UDP ports.',
        },
      },
    },
  },
  {
    name: 'read_system_logs',
    description: 'Read system or service logs from /var/log/ or systemd journalctl with optional grep filter and line limit.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        logSource: {
          type: Type.STRING,
          description: 'Log source file or systemd unit, e.g. "syslog", "nginx/error.log", "nginx/access.log", "auth.log", or "unit:docker".',
        },
        lines: {
          type: Type.INTEGER,
          description: 'Number of recent lines to retrieve (default 50, max 200).',
        },
        filter: {
          type: Type.STRING,
          description: 'Optional grep regex/string filter to find specific errors or messages.',
        },
      },
      required: ['logSource'],
    },
  },
  {
    name: 'inspect_file',
    description: 'Safely read contents of a configuration or source file with line limits.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        filePath: {
          type: Type.STRING,
          description: 'Absolute path to the file, e.g. "/etc/nginx/nginx.conf".',
        },
        maxLines: {
          type: Type.INTEGER,
          description: 'Maximum lines to read (default 100).',
        },
      },
      required: ['filePath'],
    },
  },
  {
    name: 'search_files',
    description: 'Search for files by name pattern or grep contents in a directory tree.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        directory: {
          type: Type.STRING,
          description: 'Starting directory, e.g. "/etc/nginx" or "/var/www".',
        },
        pattern: {
          type: Type.STRING,
          description: 'File name pattern or glob, e.g. "*.conf".',
        },
        contentQuery: {
          type: Type.STRING,
          description: 'Optional string to search inside files.',
        },
      },
      required: ['directory'],
    },
  },
  {
    name: 'write_file_safe',
    description: 'Safely write or update a configuration file. Automatically snapshots the previous file for instant rollback and produces a diff.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        filePath: {
          type: Type.STRING,
          description: 'Absolute path to file to write.',
        },
        content: {
          type: Type.STRING,
          description: 'The exact complete text content to write into the file.',
        },
        description: {
          type: Type.STRING,
          description: 'Brief reason for edit (stored in rollback snapshot metadata).',
        },
      },
      required: ['filePath', 'content'],
    },
  },
  {
    name: 'rollback_file_snapshot',
    description: 'Rollback a file to a previous backup snapshot version.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        filePath: {
          type: Type.STRING,
          description: 'Path of the file to revert.',
        },
        backupId: {
          type: Type.STRING,
          description: 'Specific backup snapshot ID to restore.',
        },
      },
      required: ['filePath', 'backupId'],
    },
  },
  {
    name: 'manage_service',
    description: 'Manage a Linux systemd service (status, restart, reload, start, stop, enable, disable).',
    parameters: {
      type: Type.OBJECT,
      properties: {
        serviceName: {
          type: Type.STRING,
          description: 'Name of the service, e.g. "nginx", "docker", "redis", "postgresql".',
        },
        action: {
          type: Type.STRING,
          description: 'Action to perform: "status", "restart", "reload", "start", "stop", "is-active".',
        },
      },
      required: ['serviceName', 'action'],
    },
  },
  {
    name: 'manage_docker',
    description: 'Inspect and manage Docker containers, images, and logs.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        action: {
          type: Type.STRING,
          description: 'Action: "list", "logs", "restart", "stop", "start", "inspect".',
        },
        containerIdOrName: {
          type: Type.STRING,
          description: 'Target container name or ID (required for logs, restart, stop, inspect).',
        },
        logLines: {
          type: Type.INTEGER,
          description: 'Number of log lines for logs action (default 50).',
        },
      },
      required: ['action'],
    },
  },
  {
    name: 'manage_package',
    description: 'Inspect or manage system packages using apt/dpkg.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        action: {
          type: Type.STRING,
          description: 'Action: "check_installed", "update_lists", "install", "remove".',
        },
        packageName: {
          type: Type.STRING,
          description: 'Name of the package, e.g. "htop", "certbot", "curl".',
        },
      },
      required: ['action'],
    },
  },
  {
    name: 'manage_firewall',
    description: 'Inspect or modify UFW firewall status and port rules.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        action: {
          type: Type.STRING,
          description: 'Action: "status", "allow", "deny", "delete".',
        },
        rule: {
          type: Type.STRING,
          description: 'Port or rule specification, e.g. "80/tcp", "443/tcp", "3000".',
        },
      },
      required: ['action'],
    },
  },
  {
    name: 'safe_exec_command',
    description: 'Execute an authorized diagnostic or administrative Linux shell command on the VPS with structured output capture.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        command: {
          type: Type.STRING,
          description: 'The shell command to execute.',
        },
        timeoutSeconds: {
          type: Type.INTEGER,
          description: 'Maximum execution time in seconds (default 30).',
        },
      },
      required: ['command'],
    },
  },
];

/**
 * Tool Executor Implementation
 */
export async function executeTool(
  vps: VPS,
  toolName: string,
  args: Record<string, any>
): Promise<ToolExecutionResult> {
  const startTime = Date.now();
  const vpsId = vps.id;
  const vpsName = vps.name;

  try {
    switch (toolName) {
      case 'system_diagnostics': {
        const metrics = await SSHManager.collectLiveMetrics(vps);
        let portOutput = '';
        if (args.includeNetworkPorts) {
          const portRes = await SSHManager.executeCommand(vps, 'ss -tulpn 2>/dev/null || netstat -tulpn 2>/dev/null || true');
          portOutput = `\n--- Listening Ports ---\n${portRes.stdout.trim()}`;
        }

        const out = `[System Diagnostics for ${vps.name} (${vps.host})]
Distro: ${vps.osInfo?.distro || 'Linux'} ${vps.osInfo?.release || ''} (${vps.osInfo?.arch || 'x86_64'})
CPU Usage: ${metrics?.cpuUsage ?? 'N/A'}%
RAM Usage: ${metrics?.ramUsage ?? 'N/A'}% (${metrics?.ramUsedMB ?? 0} MB / ${metrics?.ramTotalMB ?? 0} MB)
Disk Usage: ${metrics?.diskUsage ?? 'N/A'}% (${metrics?.diskUsedGB ?? 0} GB / ${metrics?.diskTotalGB ?? 0} GB)
Load Average: ${metrics?.loadAvg?.join(', ') ?? 'N/A'}
Uptime: ${metrics?.uptime ?? 'N/A'}
Process Count: ${metrics?.processCount ?? 'N/A'}
Docker Containers Running: ${metrics?.dockerRunning ?? 0}${portOutput}`;

        db.addAuditLog({
          vpsId,
          vpsName,
          action: 'TOOL_SYSTEM_DIAGNOSTICS',
          actor: 'agent',
          details: 'Retrieved full system health and resource metrics',
          status: 'success',
          exitCode: 0,
        });

        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: true,
          output: out,
          exitCode: 0,
          durationMs: Date.now() - startTime,
        };
      }

      case 'read_system_logs': {
        const lines = Math.min(200, Math.max(10, args.lines || 50));
        const filter = args.filter ? `| grep -Ei "${args.filter.replace(/"/g, '\\"')}"` : '';
        let cmd = '';

        if (args.logSource.startsWith('unit:')) {
          const unit = args.logSource.replace('unit:', '');
          cmd = `journalctl -u ${unit} -n ${lines} --no-pager ${filter}`;
        } else {
          const logFile = args.logSource.startsWith('/') ? args.logSource : `/var/log/${args.logSource}`;
          cmd = `tail -n ${lines} "${logFile}" ${filter} 2>&1`;
        }

        const res = await SSHManager.executeCommand(vps, cmd);
        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: res.exitCode === 0,
          output: res.stdout || res.stderr || '(Log file was empty)',
          exitCode: res.exitCode,
          durationMs: res.durationMs,
        };
      }

      case 'inspect_file': {
        const res = await SSHManager.readFile(vps, args.filePath, args.maxLines || 100);
        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: !res.error,
          output: res.content || res.error || '',
          exitCode: res.error ? 1 : 0,
          durationMs: Date.now() - startTime,
        };
      }

      case 'search_files': {
        const dir = args.directory || '/etc';
        const pat = args.pattern || '*';
        let cmd = `find "${dir}" -maxdepth 4 -name "${pat}" -type f 2>/dev/null | head -n 40`;
        if (args.contentQuery) {
          cmd = `grep -rnI --exclude-dir={proc,sys,dev,node_modules} "${args.contentQuery.replace(/"/g, '\\"')}" "${dir}" 2>/dev/null | head -n 30`;
        }
        const res = await SSHManager.executeCommand(vps, cmd);
        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: res.exitCode === 0,
          output: res.stdout || 'No matching files found.',
          exitCode: res.exitCode,
          durationMs: res.durationMs,
        };
      }

      case 'write_file_safe': {
        // Read previous content to compute diff
        const prev = await SSHManager.readFile(vps, args.filePath);
        const prevContent = prev.content || '';
        const newContent = args.content || '';

        const writeRes = await SSHManager.writeFile(
          vps,
          args.filePath,
          newContent,
          args.description || 'Agent configuration update'
        );

        db.addAuditLog({
          vpsId,
          vpsName,
          action: 'TOOL_WRITE_FILE',
          actor: 'agent',
          details: `Updated file ${args.filePath} (Backup ID: ${writeRes.backupId || 'None'})`,
          status: writeRes.success ? 'success' : 'failed',
          exitCode: writeRes.success ? 0 : 1,
        });

        return {
          tool: toolName,
          args: { filePath: args.filePath, description: args.description },
          vpsId,
          vpsName,
          success: writeRes.success,
          output: writeRes.success
            ? `Successfully wrote to ${args.filePath}. Backup snapshot created (${writeRes.backupId}).`
            : `Write failed: ${writeRes.error}`,
          exitCode: writeRes.success ? 0 : 1,
          durationMs: Date.now() - startTime,
          diff: {
            filePath: args.filePath,
            before: prevContent,
            after: newContent,
          },
        };
      }

      case 'rollback_file_snapshot': {
        const backup = db.getBackupById(args.backupId);
        if (!backup) {
          return {
            tool: toolName,
            args,
            vpsId,
            vpsName,
            success: false,
            output: `Backup ID ${args.backupId} not found in rollback database.`,
            exitCode: 1,
            durationMs: Date.now() - startTime,
          };
        }

        const writeRes = await SSHManager.writeFile(vps, backup.filePath, backup.content, 'Restored from rollback snapshot');
        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: writeRes.success,
          output: writeRes.success
            ? `File ${backup.filePath} successfully restored to snapshot ${backup.id} (${backup.createdAt}).`
            : `Rollback failed: ${writeRes.error}`,
          exitCode: writeRes.success ? 0 : 1,
          durationMs: Date.now() - startTime,
        };
      }

      case 'manage_service': {
        const allowedActions = ['status', 'restart', 'reload', 'start', 'stop', 'is-active', 'enable', 'disable'];
        if (!allowedActions.includes(args.action)) {
          return {
            tool: toolName,
            args,
            vpsId,
            vpsName,
            success: false,
            output: `Invalid action: ${args.action}. Allowed: ${allowedActions.join(', ')}`,
            exitCode: 1,
            durationMs: Date.now() - startTime,
          };
        }

        const cmd = `systemctl ${args.action} ${args.serviceName} 2>&1`;
        const res = await SSHManager.executeCommand(vps, cmd);

        db.addAuditLog({
          vpsId,
          vpsName,
          action: 'TOOL_MANAGE_SERVICE',
          actor: 'agent',
          details: `systemctl ${args.action} ${args.serviceName}`,
          status: res.exitCode === 0 ? 'success' : 'failed',
          exitCode: res.exitCode,
        });

        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: res.exitCode === 0,
          output: res.stdout || res.stderr || `systemctl ${args.action} ${args.serviceName} executed with exit code ${res.exitCode}`,
          exitCode: res.exitCode,
          durationMs: res.durationMs,
        };
      }

      case 'manage_docker': {
        let cmd = '';
        if (args.action === 'list') {
          cmd = 'docker ps -a --format "table {{.ID}}\\t{{.Image}}\\t{{.Status}}\\t{{.Names}}" 2>&1';
        } else if (args.action === 'logs') {
          const l = args.logLines || 50;
          cmd = `docker logs --tail ${l} "${args.containerIdOrName}" 2>&1`;
        } else if (['restart', 'stop', 'start', 'inspect'].includes(args.action)) {
          cmd = `docker ${args.action} "${args.containerIdOrName}" 2>&1`;
        } else {
          return {
            tool: toolName,
            args,
            vpsId,
            vpsName,
            success: false,
            output: `Invalid docker action: ${args.action}`,
            exitCode: 1,
            durationMs: Date.now() - startTime,
          };
        }

        const res = await SSHManager.executeCommand(vps, cmd);
        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: res.exitCode === 0,
          output: res.stdout || res.stderr,
          exitCode: res.exitCode,
          durationMs: res.durationMs,
        };
      }

      case 'manage_package': {
        let cmd = '';
        if (args.action === 'check_installed') {
          cmd = `dpkg -s "${args.packageName}" 2>&1 | head -n 15`;
        } else if (args.action === 'update_lists') {
          cmd = 'apt-get update 2>&1 | tail -n 10';
        } else if (args.action === 'install') {
          cmd = `DEBIAN_FRONTEND=noninteractive apt-get install -y "${args.packageName}" 2>&1 | tail -n 20`;
        } else if (args.action === 'remove') {
          cmd = `DEBIAN_FRONTEND=noninteractive apt-get remove -y "${args.packageName}" 2>&1 | tail -n 20`;
        }

        const res = await SSHManager.executeCommand(vps, cmd, { timeoutMs: 60000 });
        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: res.exitCode === 0,
          output: res.stdout || res.stderr,
          exitCode: res.exitCode,
          durationMs: res.durationMs,
        };
      }

      case 'manage_firewall': {
        let cmd = '';
        if (args.action === 'status') {
          cmd = 'ufw status verbose 2>&1';
        } else if (args.action === 'allow') {
          cmd = `ufw allow ${args.rule} 2>&1`;
        } else if (args.action === 'deny') {
          cmd = `ufw deny ${args.rule} 2>&1`;
        } else if (args.action === 'delete') {
          cmd = `ufw delete allow ${args.rule} 2>&1`;
        }

        const res = await SSHManager.executeCommand(vps, cmd);
        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: res.exitCode === 0,
          output: res.stdout || res.stderr,
          exitCode: res.exitCode,
          durationMs: res.durationMs,
        };
      }

      case 'safe_exec_command': {
        const timeoutMs = (args.timeoutSeconds || 30) * 1000;
        const res = await SSHManager.executeCommand(vps, args.command, { timeoutMs });

        db.addAuditLog({
          vpsId,
          vpsName,
          action: 'SHELL_EXEC',
          actor: 'agent',
          details: `Command: ${args.command}`,
          status: res.exitCode === 0 ? 'success' : 'failed',
          exitCode: res.exitCode,
        });

        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: res.exitCode === 0,
          output: res.stdout || res.stderr || '(No output produced)',
          exitCode: res.exitCode,
          durationMs: res.durationMs,
        };
      }

      default:
        return {
          tool: toolName,
          args,
          vpsId,
          vpsName,
          success: false,
          output: `Unknown tool: ${toolName}`,
          exitCode: 1,
          durationMs: Date.now() - startTime,
        };
    }
  } catch (err: any) {
    return {
      tool: toolName,
      args,
      vpsId,
      vpsName,
      success: false,
      output: `Tool execution exception: ${err.message}`,
      exitCode: 1,
      durationMs: Date.now() - startTime,
    };
  }
}
