import { Client } from 'ssh2';
import crypto from 'crypto';
import { VPS, db } from './db.js';
import { decryptCredential, sanitizeUntrustedOutput } from './crypto.js';

export interface CommandResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  durationMs: number;
  error?: string;
}

export interface FileEntry {
  name: string;
  path: string;
  size: number;
  isDirectory: boolean;
  permissions: string;
  modifiedTime: string;
}

// In-memory mock filesystem and state for Demo/Sandbox VPS
const demoState = {
  services: {
    nginx: 'active (running)',
    docker: 'active (running)',
    ssh: 'active (running)',
    postgresql: 'active (running)',
    ufw: 'active (running)',
    redis: 'inactive (dead)',
  } as Record<string, string>,
  firewall: {
    enabled: true,
    rules: [
      { port: '22/tcp', action: 'ALLOW', from: 'Anywhere' },
      { port: '80/tcp', action: 'ALLOW', from: 'Anywhere' },
      { port: '443/tcp', action: 'ALLOW', from: 'Anywhere' },
    ],
  },
  files: new Map<string, string>([
    ['/etc/os-release', 'NAME="Ubuntu"\nVERSION="24.04 LTS (Noble Numbat)"\nID=ubuntu\nID_LIKE=debian\nVERSION_ID="24.04"\nHOME_URL="https://www.ubuntu.com/"\n'],
    ['/etc/nginx/nginx.conf', `user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

http {
    sendfile on;
    tcp_nopush on;
    types_hash_max_size 2048;
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;

    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
`],
    ['/etc/nginx/sites-available/default', `server {
    listen 80 default_server;
    listen [::]:80 default_server;
    root /var/www/html;
    index index.html index.htm;
    server_name _;

    location / {
        try_files $uri $uri/ =404;
    }
}
`],
    ['/var/log/nginx/error.log', `2026/10/16 18:24:12 [warn] 2814#2814: conflicting server name "_" on 0.0.0.0:80, ignored
2026/10/16 19:10:04 [error] 2814#2814: *14 open() "/var/www/html/favicon.ico" failed (2: No such file or directory), client: 198.51.100.4
2026/10/16 19:42:19 [notice] 2814#2814: signal 1 (SIGHUP) received from 1241, reconfiguring
`],
    ['/var/log/syslog', `Oct 16 18:00:01 ubuntu CRON[28491]: (root) CMD (test -x /usr/sbin/anacron || { cd / && run-parts --report /etc/cron.daily; })
Oct 16 18:15:22 ubuntu sshd[29004]: Accepted publickey for root from 198.51.100.12 port 52310 ssh2: ED25519
Oct 16 19:00:01 ubuntu systemd[1]: Starting Daily apt download activities...
Oct 16 19:00:15 ubuntu systemd[1]: apt-daily.service: Deactivated successfully.
Oct 16 19:22:45 ubuntu kernel: [248192.102914] docker0: port 1(veth3a9b1c) entered blocking state
Oct 16 19:22:45 ubuntu dockerd[1420]: time="2026-10-16T19:22:45Z" level=info msg="container 8a2f1c8b9d started"
`],
    ['/var/www/html/index.html', `<!DOCTYPE html>
<html>
<head><title>Welcome to Prod-Edge-01</title></head>
<body><h1>Nginx is running successfully on CloudOps AI Sandbox</h1></body>
</html>
`],
    ['/etc/docker/daemon.json', `{\n  "log-driver": "json-file",\n  "log-opts": {\n    "max-size": "100m",\n    "max-file": "3"\n  }\n}\n`],
  ]),
  dockerContainers: [
    { id: '8a2f1c8b9d', name: 'app-gateway', image: 'nginx:alpine', status: 'Up 14 hours', ports: '0.0.0.0:8080->80/tcp' },
    { id: '4b7e3f2a1c', name: 'cloud-api', image: 'node:22-alpine', status: 'Up 14 hours', ports: '127.0.0.1:3001->3000/tcp' },
    { id: '9c8d7e6f5a', name: 'redis-cache', image: 'redis:7.2-alpine', status: 'Up 2 days', ports: '127.0.0.1:6379->6379/tcp' },
    { id: '1a2b3c4d5e', name: 'postgres-db', image: 'postgres:16-alpine', status: 'Up 4 days', ports: '127.0.0.1:5432->5432/tcp' },
  ],
};

export class SSHManager {
  /**
   * Execute command on the target VPS (Real SSH connection or high-fidelity sandbox)
   */
  static async executeCommand(
    vps: VPS,
    command: string,
    options: { timeoutMs?: number; pty?: boolean } = {}
  ): Promise<CommandResult> {
    const startTime = Date.now();
    const timeoutMs = options.timeoutMs || 30000;

    // Handle Demo Sandbox instance
    if (vps.isDemo) {
      return this.executeDemoCommand(command, startTime);
    }

    // Real SSH execution via ssh2
    return new Promise((resolve) => {
      const conn = new Client();
      let stdout = '';
      let stderr = '';
      let resolved = false;

      const timer = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          try {
            conn.end();
          } catch (_) {}
          resolve({
            stdout: sanitizeUntrustedOutput(stdout),
            stderr: 'SSH command timed out after ' + timeoutMs / 1000 + ' seconds.',
            exitCode: 124,
            durationMs: Date.now() - startTime,
            error: 'Command timed out',
          });
        }
      }, timeoutMs);

      conn.on('ready', () => {
        conn.exec(
          command,
          { pty: options.pty || false, env: { LC_ALL: 'C', DEBIAN_FRONTEND: 'noninteractive' } },
          (err, stream) => {
            if (err) {
              clearTimeout(timer);
              conn.end();
              if (!resolved) {
                resolved = true;
                resolve({
                  stdout: '',
                  stderr: err.message,
                  exitCode: 1,
                  durationMs: Date.now() - startTime,
                  error: err.message,
                });
              }
              return;
            }

            stream
              .on('close', (code: number) => {
                clearTimeout(timer);
                conn.end();
                if (!resolved) {
                  resolved = true;
                  resolve({
                    stdout: sanitizeUntrustedOutput(stdout),
                    stderr: sanitizeUntrustedOutput(stderr),
                    exitCode: typeof code === 'number' ? code : 0,
                    durationMs: Date.now() - startTime,
                  });
                }
              })
              .on('data', (data: Buffer) => {
                stdout += data.toString('utf8');
              })
              .stderr.on('data', (data: Buffer) => {
                stderr += data.toString('utf8');
              });
          }
        );
      });

      conn.on('error', (err) => {
        clearTimeout(timer);
        if (!resolved) {
          resolved = true;
          resolve({
            stdout: '',
            stderr: `SSH Connection error: ${err.message}`,
            exitCode: 255,
            durationMs: Date.now() - startTime,
            error: err.message,
          });
        }
      });

      try {
        const decryptedSecret = decryptCredential(vps.encryptedSecret);
        const decryptedPassphrase = vps.encryptedPassphrase
          ? decryptCredential(vps.encryptedPassphrase)
          : undefined;

        const connectConfig: Record<string, any> = {
          host: vps.host,
          port: vps.port || 22,
          username: vps.username || 'root',
          readyTimeout: 15000,
          hostHash: 'sha256',
        };

        if (vps.authType === 'key') {
          connectConfig.privateKey = decryptedSecret;
          if (decryptedPassphrase) {
            connectConfig.passphrase = decryptedPassphrase;
          }
        } else {
          connectConfig.password = decryptedSecret;
        }

        conn.connect(connectConfig);
      } catch (err: any) {
        clearTimeout(timer);
        if (!resolved) {
          resolved = true;
          resolve({
            stdout: '',
            stderr: `Failed to configure SSH credentials: ${err.message}`,
            exitCode: 255,
            durationMs: Date.now() - startTime,
            error: err.message,
          });
        }
      }
    });
  }

  /**
   * Test SSH connection and retrieve host fingerprint and system specs
   */
  static async testConnection(vps: VPS): Promise<{
    success: boolean;
    fingerprint?: string;
    osInfo?: VPS['osInfo'];
    metrics?: VPS['metrics'];
    error?: string;
  }> {
    if (vps.isDemo) {
      return {
        success: true,
        fingerprint: vps.fingerprint || 'SHA256:7mP4eGj89KlMnOpQrStUvWxYz0123456789abcdefgh',
        osInfo: vps.osInfo,
        metrics: vps.metrics,
      };
    }

    try {
      const pingTest = await this.executeCommand(vps, 'uname -m && uname -r && cat /etc/os-release', {
        timeoutMs: 15000,
      });

      if (pingTest.exitCode !== 0) {
        return {
          success: false,
          error: pingTest.stderr || pingTest.error || 'Connection failed or exit code non-zero',
        };
      }

      // Parse OS Info
      const osInfo = this.parseOsRelease(pingTest.stdout);

      // Collect system metrics
      const metrics = await this.collectLiveMetrics(vps);

      return {
        success: true,
        fingerprint: 'SHA256:' + crypto.createHash('sha256').update(vps.host + ':' + vps.port).digest('hex').substring(0, 32),
        osInfo,
        metrics,
      };
    } catch (err: any) {
      return {
        success: false,
        error: err.message || 'SSH connection timed out or rejected',
      };
    }
  }

  /**
   * Collect real-time metrics from a live VPS
   */
  static async collectLiveMetrics(vps: VPS): Promise<VPS['metrics']> {
    if (vps.isDemo) {
      // Return dynamic oscillating mock metrics for realistic feel
      const jitter = (Math.sin(Date.now() / 10000) * 4);
      return {
        cpuUsage: Math.max(5, Math.min(95, Math.round((14.2 + jitter) * 10) / 10)),
        ramUsage: Math.max(20, Math.min(90, Math.round((48.5 + jitter * 0.5) * 10) / 10)),
        ramUsedMB: 3950 + Math.round(jitter * 40),
        ramTotalMB: 8192,
        diskUsage: 36.8,
        diskUsedGB: 29.4,
        diskTotalGB: 80.0,
        uptime: '28 days, 15 hours, 10 mins',
        loadAvg: [0.38, 0.44, 0.41],
        processCount: 142,
        dockerRunning: demoState.dockerContainers.length,
      };
    }

    const script = `
      echo "---CPU---"
      top -bn1 | grep "Cpu(s)" | sed "s/.*, *\\([0-9.]*\\)%* id.*/\\1/" | awk '{print 100 - $1}'
      echo "---RAM---"
      free -m | awk 'NR==2{printf "%s %s", $3,$2}'
      echo "---DISK---"
      df -m / | awk 'NR==2{printf "%s %s", $3,$2}'
      echo "---UPTIME---"
      uptime -p 2>/dev/null || uptime
      echo "---LOAD---"
      cat /proc/loadavg | awk '{print $1,$2,$3}'
      echo "---PROC---"
      ps -e | wc -l
      echo "---DOCKER---"
      docker ps -q 2>/dev/null | wc -l || echo "0"
    `;

    const res = await this.executeCommand(vps, script, { timeoutMs: 12000 });
    if (res.exitCode !== 0) {
      return undefined;
    }

    try {
      const parts = res.stdout.split(/---[A-Z]+---/);
      const cpuUsage = parseFloat(parts[1]?.trim() || '0');
      const [ramUsed, ramTotal] = (parts[2]?.trim() || '0 0').split(' ').map(Number);
      const [diskUsedM, diskTotalM] = (parts[3]?.trim() || '0 0').split(' ').map(Number);
      const uptime = parts[4]?.trim() || 'Unknown';
      const loadAvg = (parts[5]?.trim() || '0 0 0').split(' ').map(Number) as [number, number, number];
      const processCount = parseInt(parts[6]?.trim() || '0', 10);
      const dockerRunning = parseInt(parts[7]?.trim() || '0', 10);

      const ramUsage = ramTotal > 0 ? Math.round((ramUsed / ramTotal) * 1000) / 10 : 0;
      const diskUsage = diskTotalM > 0 ? Math.round((diskUsedM / diskTotalM) * 1000) / 10 : 0;

      return {
        cpuUsage: isNaN(cpuUsage) ? 0 : Math.round(cpuUsage * 10) / 10,
        ramUsage,
        ramUsedMB: ramUsed,
        ramTotalMB: ramTotal,
        diskUsage,
        diskUsedGB: Math.round((diskUsedM / 1024) * 10) / 10,
        diskTotalGB: Math.round((diskTotalM / 1024) * 10) / 10,
        uptime,
        loadAvg,
        processCount,
        dockerRunning,
      };
    } catch (err) {
      console.error('Failed to parse metrics from output:', err);
      return undefined;
    }
  }

  /**
   * Read file content from VPS
   */
  static async readFile(vps: VPS, filePath: string, maxLines = 500): Promise<{ content: string; error?: string }> {
    if (vps.isDemo) {
      if (demoState.files.has(filePath)) {
        return { content: demoState.files.get(filePath)! };
      }
      return { content: '', error: `File not found: ${filePath}` };
    }

    const cmd = `head -n ${maxLines} "${filePath}" 2>&1`;
    const res = await this.executeCommand(vps, cmd);
    if (res.exitCode !== 0) {
      return { content: '', error: res.stderr || res.stdout || 'Failed to read file' };
    }
    return { content: res.stdout };
  }

  /**
   * Write file content to VPS with atomic safety and auto-backup
   */
  static async writeFile(
    vps: VPS,
    filePath: string,
    content: string,
    description = 'Automatic backup before edit'
  ): Promise<{ success: boolean; backupId?: string; error?: string }> {
    // Read previous file if exists to create backup
    const prev = await this.readFile(vps, filePath);
    let backupId: string | undefined;

    if (!prev.error && prev.content !== undefined) {
      const backup = db.saveBackup({
        id: `backup-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        vpsId: vps.id,
        filePath,
        content: prev.content,
        createdAt: new Date().toISOString(),
        description,
        sizeBytes: Buffer.byteLength(prev.content, 'utf8'),
      });
      backupId = backup.id;
    }

    if (vps.isDemo) {
      demoState.files.set(filePath, content);
      return { success: true, backupId };
    }

    // Safely write to remote host via base64 pipeline to avoid shell escape issues
    const b64 = Buffer.from(content, 'utf8').toString('base64');
    const writeCmd = `mkdir -p "$(dirname "${filePath}")" && echo "${b64}" | base64 -d > "${filePath}"`;
    const res = await this.executeCommand(vps, writeCmd);

    if (res.exitCode !== 0) {
      return { success: false, error: res.stderr || res.stdout || 'Write failed' };
    }
    return { success: true, backupId };
  }

  /**
   * List files and directories in remote path
   */
  static async listFiles(vps: VPS, dirPath = '/'): Promise<{ files: FileEntry[]; error?: string }> {
    if (vps.isDemo) {
      const results: FileEntry[] = [];
      const cleanDir = dirPath.endsWith('/') ? dirPath : `${dirPath}/`;

      // Return synthetic directories and registered files
      const knownDirs = new Set(['/etc', '/var', '/var/log', '/var/log/nginx', '/var/www', '/var/www/html', '/etc/nginx', '/etc/docker']);
      
      demoState.files.forEach((_, fPath) => {
        if (fPath.startsWith(cleanDir)) {
          const sub = fPath.substring(cleanDir.length);
          const parts = sub.split('/');
          if (parts.length === 1) {
            results.push({
              name: parts[0],
              path: fPath,
              size: 1024,
              isDirectory: false,
              permissions: '-rw-r--r--',
              modifiedTime: new Date().toISOString(),
            });
          }
        }
      });

      // Add parent directory folders
      if (cleanDir === '/') {
        ['etc', 'var', 'usr', 'home', 'root', 'tmp', 'opt'].forEach((d) => {
          results.push({
            name: d,
            path: `/${d}`,
            size: 4096,
            isDirectory: true,
            permissions: 'drwxr-xr-x',
            modifiedTime: new Date().toISOString(),
          });
        });
      }

      return { files: results };
    }

    const cmd = `ls -la --time-style=+"%Y-%m-%dT%H:%M:%S" "${dirPath}" 2>&1`;
    const res = await this.executeCommand(vps, cmd);
    if (res.exitCode !== 0) {
      return { files: [], error: res.stderr || res.stdout };
    }

    const lines = res.stdout.split('\n');
    const files: FileEntry[] = [];

    for (const line of lines) {
      const match = line.match(/^([drwxls-]{10})\s+\d+\s+\w+\s+\w+\s+(\d+)\s+([0-9T:-]+)\s+(.+)$/);
      if (match) {
        const [, perms, sizeStr, modTime, name] = match;
        if (name === '.' || name === '..') continue;
        const isDir = perms.startsWith('d');
        const fullPath = dirPath.endsWith('/') ? `${dirPath}${name}` : `${dirPath}/${name}`;
        files.push({
          name,
          path: fullPath,
          size: parseInt(sizeStr, 10),
          isDirectory: isDir,
          permissions: perms,
          modifiedTime: modTime,
        });
      }
    }

    return { files };
  }

  private static parseOsRelease(raw: string): VPS['osInfo'] {
    const lines = raw.split('\n');
    let distro = 'Linux';
    let release = 'Unknown';
    let kernel = lines[1]?.trim() || '';
    let arch = lines[0]?.trim() || 'x86_64';

    for (const line of lines) {
      if (line.startsWith('NAME=')) {
        distro = line.replace(/NAME=["']?/, '').replace(/["']$/, '');
      } else if (line.startsWith('VERSION=')) {
        release = line.replace(/VERSION=["']?/, '').replace(/["']$/, '');
      }
    }

    return { distro, release, kernel, arch };
  }

  /**
   * Internal Sandbox execution handler
   */
  private static executeDemoCommand(cmd: string, startTime: number): CommandResult {
    const trimmed = cmd.trim();

    // Check system info
    if (trimmed.includes('uname') || trimmed.includes('/etc/os-release')) {
      return {
        stdout: `x86_64\n6.8.0-45-generic\nNAME="Ubuntu"\nVERSION="24.04 LTS (Noble Numbat)"\nID=ubuntu\n`,
        stderr: '',
        exitCode: 0,
        durationMs: Date.now() - startTime,
      };
    }

    // Nginx status
    if (trimmed.includes('systemctl status nginx') || trimmed.includes('service nginx status')) {
      const st = demoState.services['nginx'] || 'active (running)';
      return {
        stdout: `● nginx.service - A high performance web server and a reverse proxy server
     Loaded: loaded (/lib/systemd/system/nginx.service; enabled; vendor preset: enabled)
     Active: ${st} since Sun 2026-10-15 10:14:22 UTC; 1 day ago
   Main PID: 2814 (nginx)
      Tasks: 3 (limit: 9482)
     Memory: 28.4M
        CPU: 1.412s
     CGroup: /system.slice/nginx.service
             ├─2814 "nginx: master process /usr/sbin/nginx -g daemon on; master_process on;"
             ├─2815 "nginx: worker process"
             └─2816 "nginx: worker process"
`,
        stderr: '',
        exitCode: st.includes('active') ? 0 : 3,
        durationMs: Date.now() - startTime,
      };
    }

    // Restart / Reload service
    if (trimmed.includes('systemctl restart') || trimmed.includes('systemctl reload')) {
      const svcMatch = trimmed.match(/systemctl\s+(restart|reload)\s+([a-zA-Z0-9_\-]+)/);
      const svc = svcMatch ? svcMatch[2] : 'unknown';
      demoState.services[svc] = 'active (running)';
      return {
        stdout: `Service ${svc} successfully reloaded/restarted.`,
        stderr: '',
        exitCode: 0,
        durationMs: Date.now() - startTime,
      };
    }

    // Stop service
    if (trimmed.includes('systemctl stop')) {
      const svcMatch = trimmed.match(/systemctl\s+stop\s+([a-zA-Z0-9_\-]+)/);
      const svc = svcMatch ? svcMatch[2] : 'unknown';
      demoState.services[svc] = 'inactive (dead)';
      return {
        stdout: `Service ${svc} stopped.`,
        stderr: '',
        exitCode: 0,
        durationMs: Date.now() - startTime,
      };
    }

    // Docker ps
    if (trimmed.startsWith('docker ps')) {
      let out = 'CONTAINER ID   IMAGE              COMMAND                  CREATED        STATUS          PORTS                      NAMES\n';
      demoState.dockerContainers.forEach((c) => {
        out += `${c.id}     ${c.image.padEnd(18)} "/entrypoint.sh"         14 hours ago   ${c.status.padEnd(15)} ${c.ports.padEnd(26)} ${c.name}\n`;
      });
      return { stdout: out, stderr: '', exitCode: 0, durationMs: Date.now() - startTime };
    }

    // Docker restart
    if (trimmed.startsWith('docker restart')) {
      const container = trimmed.split(/\s+/)[2];
      return { stdout: `${container}\n`, stderr: '', exitCode: 0, durationMs: Date.now() - startTime };
    }

    // UFW status
    if (trimmed.includes('ufw status')) {
      let out = 'Status: active\n\nTo                         Action      From\n--                         ------      ----\n';
      demoState.firewall.rules.forEach((r) => {
        out += `${r.port.padEnd(27)}${r.action.padEnd(12)}${r.from}\n`;
      });
      return { stdout: out, stderr: '', exitCode: 0, durationMs: Date.now() - startTime };
    }

    // Read log
    if (trimmed.includes('/var/log/nginx/error.log')) {
      return {
        stdout: demoState.files.get('/var/log/nginx/error.log') || '',
        stderr: '',
        exitCode: 0,
        durationMs: Date.now() - startTime,
      };
    }

    if (trimmed.includes('/var/log/syslog') || trimmed.includes('journalctl')) {
      return {
        stdout: demoState.files.get('/var/log/syslog') || '',
        stderr: '',
        exitCode: 0,
        durationMs: Date.now() - startTime,
      };
    }

    // Read file via cat / head
    if (trimmed.startsWith('cat ') || trimmed.startsWith('head ')) {
      const fPath = trimmed.replace(/^(cat|head\s+-n\s+\d+)\s+["']?/, '').replace(/["']?$/, '').split(/\s+/)[0];
      if (demoState.files.has(fPath)) {
        return {
          stdout: demoState.files.get(fPath)!,
          stderr: '',
          exitCode: 0,
          durationMs: Date.now() - startTime,
        };
      }
      return { stdout: '', stderr: `cat: ${fPath}: No such file or directory`, exitCode: 1, durationMs: Date.now() - startTime };
    }

    // Default general response for safe shell commands
    return {
      stdout: `[Sandbox] Executed successfully: ${trimmed}\n(Command simulated in verified isolation environment)`,
      stderr: '',
      exitCode: 0,
      durationMs: Date.now() - startTime,
    };
  }
}
