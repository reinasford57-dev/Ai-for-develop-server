import crypto from 'crypto';

// Secret key for AES-256-GCM encryption of stored credentials.
// In production, configure MASTER_ENCRYPTION_KEY in environment variables.
const MASTER_KEY_STRING = process.env.MASTER_ENCRYPTION_KEY || 'cloudops-ai-default-master-key-32b-sec';
const ENCRYPTION_KEY = crypto.createHash('sha256').update(MASTER_KEY_STRING).digest();
const ALGORITHM = 'aes-256-gcm';

export interface EncryptedData {
  iv: string;
  authTag: string;
  data: string;
}

/**
 * Encrypt sensitive credential strings (private keys, passwords, passphrases)
 */
export function encryptCredential(plainText: string): string {
  if (!plainText) return '';
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
  let encrypted = cipher.update(plainText, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  
  // Format: iv:authTag:encrypted
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

/**
 * Decrypt sensitive credential string
 */
export function decryptCredential(cipherPayload: string): string {
  if (!cipherPayload) return '';
  try {
    const parts = cipherPayload.split(':');
    if (parts.length !== 3) {
      // Fallback in case raw text was stored
      return cipherPayload;
    }
    const [ivHex, authTagHex, encryptedHex] = parts;
    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');
    const decipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
    decipher.setAuthTag(authTag);
    let decrypted = decipher.update(encryptedHex, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    console.error('Decryption failed for credential:', err);
    return '';
  }
}

/**
 * Mask sensitive data for safe display in frontend or AI prompt
 */
export function maskSecret(secret?: string): string {
  if (!secret) return '';
  if (secret.length <= 8) return '********';
  return `${secret.substring(0, 3)}...${secret.substring(secret.length - 3)}`;
}

/**
 * Sanitize untrusted output from VPS (logs, file contents) to prevent prompt injection
 */
export function sanitizeUntrustedOutput(raw: string, maxLen = 8000): string {
  if (!raw) return '';
  let cleaned = raw;
  if (cleaned.length > maxLen) {
    cleaned = cleaned.substring(0, maxLen) + `\n...[Truncated: output exceeded ${maxLen} chars]...`;
  }
  // Wrap with explicit untrusted data markers
  return cleaned;
}
