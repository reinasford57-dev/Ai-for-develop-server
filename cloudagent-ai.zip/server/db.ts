import fs from 'fs';
import path from 'path';
import { encryptCredential } from './crypto.js';

export interface VPS {
  id: string;
  name: string;
  host: string;
  port: number;
  username: string;
  authType: 'key' | 'password';
  encryptedSecret: string;
  encryptedPassphrase?: string;
  fingerprint?: string;
  tags: string[];
  status: 'online' | 'offline' | 'untested' | 'error';
  lastChecked?: string;
  osInfo?: {
    distro: string;
    release: string;
    kernel: string;
    arch: string;
  };
  metrics?: {
    cpuUsage: number;
    ramUsage: number;
    ramUsedMB: number;
    ramTotalMB: number;
    diskUsage: number;
    diskUsedGB: number;
    diskTotalGB: number;
    uptime: string;
    loadAvg: [number, number, number];
    processCount: number;
    dockerRunning?: number;
  };
  isDemo?: boolean;
}

export interface PlanStep {
  id: number;
  title: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'skipped';
  details?: string;
}

export interface ToolInvocation {
  id: string;
  tool: string;
  args: Record<string, any>;
  vpsId: string;
  vpsName: string;
  status: 'pending' | 'requires_approval' | 'approved' | 'rejected' | 'running' | 'success' | 'failed';
  output?: string;
  exitCode?: number;
  error?: string;
  timestamp: string;
  diff?: {
    filePath: string;
    before: string;
    after: string;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  targetVpsId?: string;
  plan?: {
    summary: string;
    steps: PlanStep[];
  };
  toolInvocations?: ToolInvocation[];
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  targetVpsId?: string;
  messages: ChatMessage[];
}

export interface TaskJob {
  id: string;
  title: string;
  vpsId: string;
  vpsName: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  logs: string[];
  createdAt: string;
  completedAt?: string;
  error?: string;
}

export interface BackupSnapshot {
  id: string;
  vpsId: string;
  filePath: string;
  content: string;
  createdAt: string;
  description: string;
  sizeBytes: number;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  vpsId?: string;
  vpsName?: string;
  action: string;
  actor: 'user' | 'agent';
  details: string;
  status: 'success' | 'failed' | 'warning';
  exitCode?: number;
}

export interface AppSettings {
  geminiModel: string;
  maxAgentSteps: number;
  commandTimeoutSeconds: number;
  requireApprovalForRisky: boolean;
  systemPromptCustom: string;
}

interface DatabaseSchema {
  servers: VPS[];
  sessions: ChatSession[];
  tasks: TaskJob[];
  backups: BackupSnapshot[];
  auditLogs: AuditLog[];
  settings: AppSettings;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
    if (!this.data.servers || this.data.servers.length === 0) {
      this.seedInitialData();
    }
  }

  private load(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.error('Failed to load db.json, initializing fresh db:', err);
    }

    return {
      servers: [],
      sessions: [],
      tasks: [],
      backups: [],
      auditLogs: [],
      settings: {
        geminiModel: 'gemini-3.8-flash',
        maxAgentSteps: 10,
        commandTimeoutSeconds: 30,
        requireApprovalForRisky: true,
        systemPromptCustom: '',
      },
    };
  }

  private save(): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const tmp = `${DB_FILE}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(this.data, null, 2), 'utf8');
      fs.renameSync(tmp, DB_FILE);
    } catch (err) {
      console.error('Error saving db.json:', err);
    }
  }

  private seedInitialData(): void {
    const demoServer: VPS = {
      id: 'vps-demo-production-01',
      name: 'Prod-Edge-01 (Sandbox)',
      host: '127.0.0.1',
      port: 22,
      username: 'root',
      authType: 'key',
      encryptedSecret: encryptCredential('ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGroundDemoKeyForAIStudioEnvironmentTest== demo@cloudops'),
      fingerprint: 'SHA256:7mP4eGj89KlMnOpQrStUvWxYz0123456789abcdefgh',
      tags: ['production', 'web', 'docker'],
      status: 'online',
      lastChecked: new Date().toISOString(),
      osInfo: {
        distro: 'Ubuntu Linux',
        release: '24.04 LTS (Noble Numbat)',
        kernel: '6.8.0-45-generic',
        arch: 'x86_64',
      },
      metrics: {
        cpuUsage: 14.2,
        ramUsage: 48.5,
        ramUsedMB: 3950,
        ramTotalMB: 8192,
        diskUsage: 36.8,
        diskUsedGB: 29.4,
        diskTotalGB: 80.0,
        uptime: '28 days, 14 hours, 32 mins',
        loadAvg: [0.34, 0.42, 0.39],
        processCount: 142,
        dockerRunning: 4,
      },
      isDemo: true,
    };

    const initialAudit: AuditLog = {
      id: 'audit-init-01',
      timestamp: new Date().toISOString(),
      vpsId: demoServer.id,
      vpsName: demoServer.name,
      action: 'SYSTEM_BOOTSTRAP',
      actor: 'user',
      details: 'CloudOps AI Agent platform initialized with secure vault and sandbox instance.',
      status: 'success',
      exitCode: 0,
    };

    this.data.servers = [demoServer];
    this.data.auditLogs = [initialAudit];
    this.save();
  }

  // --- Servers ---
  getServers(): VPS[] {
    return this.data.servers;
  }

  getServerById(id: string): VPS | undefined {
    return this.data.servers.find((s) => s.id === id);
  }

  saveServer(server: VPS): VPS {
    const idx = this.data.servers.findIndex((s) => s.id === server.id);
    if (idx >= 0) {
      this.data.servers[idx] = server;
    } else {
      this.data.servers.push(server);
    }
    this.save();
    return server;
  }

  deleteServer(id: string): boolean {
    const lenBefore = this.data.servers.length;
    this.data.servers = this.data.servers.filter((s) => s.id !== id);
    if (this.data.servers.length !== lenBefore) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Chat Sessions ---
  getSessions(): ChatSession[] {
    return this.data.sessions.sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }

  getSessionById(id: string): ChatSession | undefined {
    return this.data.sessions.find((s) => s.id === id);
  }

  saveSession(session: ChatSession): ChatSession {
    const idx = this.data.sessions.findIndex((s) => s.id === session.id);
    if (idx >= 0) {
      this.data.sessions[idx] = session;
    } else {
      this.data.sessions.push(session);
    }
    this.save();
    return session;
  }

  deleteSession(id: string): boolean {
    const lenBefore = this.data.sessions.length;
    this.data.sessions = this.data.sessions.filter((s) => s.id !== id);
    if (this.data.sessions.length !== lenBefore) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Tasks ---
  getTasks(): TaskJob[] {
    return this.data.tasks.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  getTaskById(id: string): TaskJob | undefined {
    return this.data.tasks.find((t) => t.id === id);
  }

  saveTask(task: TaskJob): TaskJob {
    const idx = this.data.tasks.findIndex((t) => t.id === task.id);
    if (idx >= 0) {
      this.data.tasks[idx] = task;
    } else {
      this.data.tasks.push(task);
    }
    this.save();
    return task;
  }

  // --- Backups & Rollbacks ---
  getBackups(vpsId?: string, filePath?: string): BackupSnapshot[] {
    return this.data.backups.filter((b) => {
      if (vpsId && b.vpsId !== vpsId) return false;
      if (filePath && b.filePath !== filePath) return false;
      return true;
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  saveBackup(backup: BackupSnapshot): BackupSnapshot {
    this.data.backups.unshift(backup);
    // Keep max 200 backups
    if (this.data.backups.length > 200) {
      this.data.backups = this.data.backups.slice(0, 200);
    }
    this.save();
    return backup;
  }

  getBackupById(id: string): BackupSnapshot | undefined {
    return this.data.backups.find((b) => b.id === id);
  }

  // --- Audit Logs ---
  getAuditLogs(limit = 100): AuditLog[] {
    return this.data.auditLogs.slice(0, limit);
  }

  addAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>): AuditLog {
    const newLog: AuditLog = {
      ...log,
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(newLog);
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 500);
    }
    this.save();
    return newLog;
  }

  // --- Settings ---
  getSettings(): AppSettings {
    return this.data.settings;
  }

  updateSettings(settings: Partial<AppSettings>): AppSettings {
    this.data.settings = { ...this.data.settings, ...settings };
    this.save();
    return this.data.settings;
  }
}

export const db = new Database();
