import asyncio
import asyncssh
from typing import Dict, Any, Optional
from backend.models import Server
from backend.services.crypto import decrypt_secret

class AsyncSSHManager:
    @staticmethod
    async def execute_command(
        server: Server,
        command: str,
        timeout: int = 30
    ) -> Dict[str, Any]:
        """
        Connect to server via AsyncSSH and execute command with timeout and error handling
        """
        secret = decrypt_secret(server.encrypted_secret)
        options = asyncssh.SSHClientConnectionOptions(
            known_hosts=None,  # Or strictly validated known hosts path
        )

        connect_kwargs: Dict[str, Any] = {
            "host": server.host,
            "port": server.port,
            "username": server.username,
            "options": options,
        }

        if server.auth_type == "key":
            connect_kwargs["client_keys"] = [asyncssh.import_private_key(secret)]
        else:
            connect_kwargs["password"] = secret

        try:
            async with asyncssh.connect(**connect_kwargs) as conn:
                result = await asyncio.wait_for(conn.run(command), timeout=timeout)
                return {
                    "stdout": result.stdout or "",
                    "stderr": result.stderr or "",
                    "exit_code": result.exit_status,
                    "success": result.exit_status == 0,
                }
        except asyncio.TimeoutError:
            return {
                "stdout": "",
                "stderr": f"Command timed out after {timeout} seconds",
                "exit_code": 124,
                "success": False,
            }
        except Exception as e:
            return {
                "stdout": "",
                "stderr": f"SSH connection/execution error: {str(e)}",
                "exit_code": 255,
                "success": False,
            }
