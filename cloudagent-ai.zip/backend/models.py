import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, Boolean, Text, JSON, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from backend.database import Base

def gen_uuid():
    return str(uuid.uuid4())

def utc_now():
    return datetime.now(timezone.utc)

class Server(Base):
    __tablename__ = "servers"

    id = Column(String, primary_key=True, default=gen_uuid)
    name = Column(String(100), nullable=False)
    host = Column(String(255), nullable=False)
    port = Column(Integer, default=22)
    username = Column(String(100), nullable=False)
    auth_type = Column(String(20), default="key")  # 'key' or 'password'
    encrypted_secret = Column(Text, nullable=False)
    encrypted_passphrase = Column(Text, nullable=True)
    fingerprint = Column(String(255), nullable=True)
    tags = Column(JSON, default=list)
    status = Column(String(30), default="untested")
    last_checked = Column(DateTime, default=utc_now)
    os_info = Column(JSON, default=dict)
    metrics = Column(JSON, default=dict)
    is_demo = Column(Boolean, default=False)

class ChatSession(Base):
    __tablename__ = "chat_sessions"

    id = Column(String, primary_key=True, default=gen_uuid)
    title = Column(String(200), default="New CloudOps Session")
    target_vps_id = Column(String, nullable=True)
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    messages = relationship("ChatMessage", back_populates="session", cascade="all, delete-orphan")

class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(String, primary_key=True, default=gen_uuid)
    session_id = Column(String, ForeignKey("chat_sessions.id"))
    role = Column(String(20), nullable=False)  # 'user', 'assistant', 'system'
    content = Column(Text, nullable=False)
    target_vps_id = Column(String, nullable=True)
    plan = Column(JSON, nullable=True)
    tool_invocations = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=utc_now)

    session = relationship("ChatSession", back_populates="messages")

class TaskJob(Base):
    __tablename__ = "tasks"

    id = Column(String, primary_key=True, default=gen_uuid)
    title = Column(String(200), nullable=False)
    vps_id = Column(String, nullable=False)
    vps_name = Column(String(100), nullable=False)
    status = Column(String(30), default="pending")  # pending, running, completed, failed, cancelled
    progress = Column(Integer, default=0)
    logs = Column(JSON, default=list)
    created_at = Column(DateTime, default=utc_now)
    completed_at = Column(DateTime, nullable=True)
    error = Column(Text, nullable=True)

class BackupSnapshot(Base):
    __tablename__ = "backups"

    id = Column(String, primary_key=True, default=gen_uuid)
    vps_id = Column(String, nullable=False)
    file_path = Column(String(500), nullable=False)
    content = Column(Text, nullable=False)
    description = Column(String(255), default="Pre-edit snapshot")
    size_bytes = Column(Integer, default=0)
    created_at = Column(DateTime, default=utc_now)

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String, primary_key=True, default=gen_uuid)
    timestamp = Column(DateTime, default=utc_now)
    vps_id = Column(String, nullable=True)
    vps_name = Column(String(100), nullable=True)
    action = Column(String(100), nullable=False)
    actor = Column(String(20), default="user")
    details = Column(Text, nullable=False)
    status = Column(String(20), default="success")
    exit_code = Column(Integer, nullable=True)
