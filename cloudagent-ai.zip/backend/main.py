from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.config import settings

app = FastAPI(
    title=settings.APP_NAME,
    description="Production-Ready AI Cloud Agent Backend for Multi-VPS Control",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "env": settings.ENV,
        "default_model": settings.DEFAULT_GEMINI_MODEL,
    }

@app.get("/api/info")
async def app_info():
    return {
        "version": "1.0.0",
        "features": [
            "Multi-VPS Management",
            "AsyncSSH Connection Engine",
            "Autonomous Gemini Cloud Agent",
            "Structured Server Tools & Allowlist",
            "Real-time SSE Streaming",
            "Diff & Snapshot Rollback",
            "Security Vault & Audit Trail"
        ]
    }
