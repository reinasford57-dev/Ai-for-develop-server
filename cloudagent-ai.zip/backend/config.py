import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = "CloudOps AI Agent"
    ENV: str = os.getenv("ENV", "development")
    PORT: int = int(os.getenv("PORT", 8000))
    SECRET_KEY: str = os.getenv("SECRET_KEY", "cloudops-insecure-default-secret-key-32b")
    MASTER_ENCRYPTION_KEY: str = os.getenv("MASTER_ENCRYPTION_KEY", "cloudops-default-aes-encryption-key-32b")
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./data/cloudops.db")
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    DEFAULT_GEMINI_MODEL: str = "gemini-3.8-flash"
    SSH_DEFAULT_TIMEOUT: int = 30
    REQUIRE_APPROVAL_FOR_RISKY: bool = True
    MAX_AGENT_STEPS: int = 10

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
