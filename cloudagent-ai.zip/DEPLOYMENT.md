# CloudOps AI Agent — Production Deployment Guide

This guide details how to deploy the **CloudOps AI Agent** platform in production, optimized for cost-effectiveness and security.

---

## 1. Architecture Overview

- **Frontend & Fullstack Engine**: React 19 + TypeScript + Vite + Tailwind CSS + Express on Node 22.
- **SSH Engine**: `ssh2` and `AsyncSSH` with ED25519/RSA key auth, fingerprint verification, timeout controls, and structured tool allowlist.
- **AI Agent**: Gemini 3.8 Flash via `@google/genai` with multi-step reasoning, tool calling, and SSE streaming.
- **Security Vault**: AES-256-GCM encryption for stored private keys/passwords, with prompt injection isolation barriers.

---

## 2. Low-Cost & Free-Tier Hosting Options

### A. Oracle Cloud Always Free (Recommended — $0/month)
- **Specs**: 4 ARM Ampere cores, 24 GB RAM, 200 GB storage.
- **Cost**: 100% Free Forever.
- **Deployment**:
  1. Launch an Ubuntu 24.04 ARM instance.
  2. Open port 80 and 443 in Oracle VCN Security Lists.
  3. Install Docker:
     ```bash
     curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh
     ```
  4. Clone the repository and run:
     ```bash
     docker compose up -d
     ```

### B. Render / Railway / Fly.io (Free / Low Cost ~$5/mo)
- Set environment variables:
  - `GEMINI_API_KEY`: Your Gemini API key from AI Studio
  - `NODE_ENV`: `production`
  - `MASTER_ENCRYPTION_KEY`: A random 32-character secret string
- Docker build will automatically compile frontend assets and start the application on port 3000.

---

## 3. Environment Variables

Create `.env` based on `.env.example`:

```bash
# Gemini AI Configuration
GEMINI_API_KEY="your-gemini-api-key"

# AES-256 Master Key for Encrypting VPS Private Keys & Passwords
MASTER_ENCRYPTION_KEY="replace-with-a-random-32-byte-hex-or-string"

# Port & Node Environment
PORT=3000
NODE_ENV=production
```

---

## 4. Security Hardening Checklist

1. **Firewall (UFW)**:
   ```bash
   ufw allow 22/tcp
   ufw allow 80/tcp
   ufw allow 443/tcp
   ufw enable
   ```
2. **Dedicated Deployment User**: Never run the web agent as root on the hosting server. Use the bundled non-root Docker container.
3. **SSH Keys**:
   - Generate an ED25519 key pair for your agent:
     ```bash
     ssh-keygen -t ed25519 -C "cloudops-agent" -f ~/.ssh/cloudops_ed25519
     ```
   - Copy public key to managed VPS:
     ```bash
     ssh-copy-id -i ~/.ssh/cloudops_ed25519.pub user@target-vps-ip
     ```
4. **Least-Privilege Sudoers**:
   On managed Linux servers, grant specific sudo privileges rather than blank root:
   ```sudoers
   cloudops ALL=(ALL) NOPASSWD: /usr/bin/systemctl, /usr/bin/journalctl, /usr/bin/docker, /usr/bin/apt-get
   ```
