import { encryptCredential, decryptCredential, maskSecret } from '../server/crypto.js';
import { db } from '../server/db.js';
import { isOperationHighRisk, executeTool } from '../server/tools.js';
import { SSHManager } from '../server/ssh.js';

async function runTests() {
  console.log('🧪 Starting CloudOps AI Agent Test Suite...\n');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, msg: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${msg}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${msg}`);
      failed++;
    }
  }

  // 1. Encryption & Masking Tests
  console.log('1. Testing Security Vault & AES-256-GCM:');
  const secret = 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAISecretPrivateKey12345';
  const encrypted = encryptCredential(secret);
  assert(encrypted !== secret && encrypted.includes(':'), 'Credential is encrypted into authenticated format');
  const decrypted = decryptCredential(encrypted);
  assert(decrypted === secret, 'Decrypted credential matches original secret exactly');
  const masked = maskSecret('superSecretPassword123');
  assert(masked.startsWith('sup') && masked.endsWith('123') && masked.includes('...'), 'Secret is properly masked for safe display');

  // 2. High-Risk Safety Rule Tests
  console.log('\n2. Testing High-Risk Safety Policy Engine:');
  const risk1 = isOperationHighRisk('write_file_safe', { filePath: '/etc/nginx/nginx.conf' });
  assert(risk1.isHighRisk === true, 'Modifying /etc/ file is correctly flagged as high-risk');

  const risk2 = isOperationHighRisk('manage_service', { serviceName: 'ssh', action: 'restart' });
  assert(risk2.isHighRisk === true, 'Restarting ssh service is flagged as high-risk');

  const risk3 = isOperationHighRisk('manage_package', { action: 'remove', packageName: 'nginx' });
  assert(risk3.isHighRisk === true, 'Uninstalling system package is flagged as high-risk');

  const risk4 = isOperationHighRisk('inspect_file', { filePath: '/etc/nginx/nginx.conf' });
  assert(risk4.isHighRisk === false, 'Read-only inspection is safe and does not require approval');

  // 3. Database Persistence Tests
  console.log('\n3. Testing Database CRUD & Rollback Snapshots:');
  const servers = db.getServers();
  assert(servers.length > 0, 'Database contains at least one default server/sandbox');

  const demoServer = servers[0];
  const testBackup = db.saveBackup({
    id: `backup-test-${Date.now()}`,
    vpsId: demoServer.id,
    filePath: '/etc/test.conf',
    content: 'original_content = true',
    createdAt: new Date().toISOString(),
    description: 'Unit test snapshot',
    sizeBytes: 23,
  });
  assert(db.getBackupById(testBackup.id) !== undefined, 'Backup snapshot persisted in rollback vault');

  // 4. SSH & Sandbox Execution Tests
  console.log('\n4. Testing Tool Execution & Host Diagnostics:');
  const diagResult = await executeTool(demoServer, 'system_diagnostics', {});
  assert(diagResult.success === true, 'system_diagnostics tool executes successfully');
  assert(diagResult.output.includes('System Diagnostics'), 'Diagnostics output formatted correctly');

  const logResult = await executeTool(demoServer, 'read_system_logs', { logSource: 'nginx/error.log', lines: 10 });
  assert(logResult.success === true, 'read_system_logs tool executes successfully');

  console.log(`\n========================================`);
  console.log(`Test Summary: ${passed} Passed, ${failed} Failed`);
  console.log(`========================================\n`);

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Fatal test runner error:', err);
  process.exit(1);
});
